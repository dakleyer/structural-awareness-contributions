# Executed ablation — A4 (remove P4) against 00H, "The Quiet Four Thousand"

## What this is

A **first, partial execution** of one of the six 00K ablations — a deterministic,
rule-level simulation, not a test of any real LLM agent or commercial product.
It encodes 00H's frozen Branch U / Branch G / Branch I fixture (§14 of the v0.5
draft) and 00K's strongest-repair protocol (§4) as runnable Python, then
actually runs it.

## What it tests

Removed principle: **P4 — Qualification-preserving handoff and authority lineage**
Unique ablation anchor: **S8 — Bounded subdelegation and non-amplification**

Four genuine rescue attempts are tried, using only the other five principles
plus one realistic native control, exactly as 00K's protocol requires (no
capability is disabled merely because it happens to share a gate with P4):

1. **P1 alone** (stricter evidence sufficiency)
2. **P5 alone** (revalidate every leaf grant immediately before use)
3. **P6 alone** (detect that a common-root campaign exists, but do nothing with that fact)
4. **A realistic native control** (a per-hour action-rate cap, the kind almost any
   production system already has)

Each is checked against **both** Branch U (unauthorized common-root campaign —
must stay blocked) **and** Branch G (genuinely authorized campaign — must stay
allowed), because a rescue that blocks both is a deny-all in disguise, not a fix.

## Result

**11 of 11 tests pass.** Concretely:

- Route Q (all six principles, including P4) correctly separates Branch U,
  Branch G and Branch I.
- Every rescue attempt using P1, P5, or P6 alone **wrongly executes** Branch U
  — none of them ever inspects root campaign authority, so none of them can
  tell the difference.
- The native rate cap **does** stop Branch U — but the same test shows it
  **also blocks Branch G**, the genuinely authorized campaign, at the exact
  same threshold. It cannot distinguish the two because it was never given
  anything to distinguish them with.
- No TRUE SUBSTITUTE was found among the four attempts tried. Every rescue
  that touched the actual U/G distinction did so by checking
  `RootCampaignAuthority` — i.e., by reconstructing P4.

## What this does and does not establish

**Does:** provide one concrete, re-runnable, falsifiable data point for 00K's
ablation A4, with real code instead of prose argument. Anyone can run
`pytest -v test_ablation_A4.py`, change the rescue functions, and try to make
a rescue pass both Branch U and Branch G without touching root authority.
If someone succeeds, that is a real result against P4's necessity claim —
the code is built to allow that, not to prevent it.

**Does not:**
- test any real agent framework, LLM, or product;
- execute A1, A2, A3, A5 or A6 (the other five 00K ablations);
- prove universal necessity of P4 — only that four specific, plausible
  rescue attempts fail within this fixture;
- constitute a benchmark, certification, or comparative claim of any kind.

## v0.2 addition — aligned to 00K-A03 §10's four-arm design

An independently-authored companion "paper execution" of this same ablation
(00K-A03, in the corpus) proposed the next evidence tier as a four-arm
runtime comparison. This harness now implements exactly those four arms:

1. `ablated_no_rescue` — −P4 leaf/local baseline
2. `ablated_rescue_native_rate_cap` — −P4 + strongest non-lineage repair
3. `a2l_strong_peer_decision` — **A2-L**, a deliberately non-EA-branded
   strong peer that reconstructs root/delegation lineage under its own
   name, exactly matching 00K-A03's classification of this repair as
   **SEMANTIC RECONSTRUCTION**, not proof that EA/EP is uniquely necessary
4. `route_q_decision` — the full six-principle, requirements-conforming route

`test_four_arm_comparison_table` runs all four against Branch U and then
against Branch G, and prints the result table. Arms 3 and 4 both correctly
discriminate; arm 2 blocks both branches alike (the deny-all trap, made
visible as two numbers instead of an argument); arm 1 executes the
unauthorized campaign outright.

An `NM` branch (2 accounts / USD 11, below `00H-MAT-1`) was also added
across every arm, verbatim from 00K-A03 — arrived at independently, with
the same numbers, before this file had ever cited that document.

## How to extend this

The honest next move is for someone (human or another model) to try to
defeat `test_ablated_native_rate_cap_ALSO_blocks_branch_G` — write a fifth
rescue function in `ablation_A4.py` that passes both Branch U and Branch G
without adding anything resembling `RootCampaignAuthority`. That is exactly
the TRUE SUBSTITUTE case 00K's protocol asks for, and this harness is built
so that attempt is one function and one test away, not a redesign.

## Files

- `ablation_A4.py` — the simulation: Route Q and four ablated rescue attempts.
- `test_ablation_A4.py` — the pytest suite that runs and checks all of it.
- Run with: `pip install pytest && pytest -v test_ablation_A4.py`
