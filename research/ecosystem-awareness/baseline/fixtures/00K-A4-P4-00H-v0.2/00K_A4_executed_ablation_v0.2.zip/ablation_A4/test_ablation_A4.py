"""
test_ablation_A4.py — executes 00K ablation A4 (remove P4) against 00H's
frozen Branch U / Branch G / Branch I fixture.

Run with:  pytest -v test_ablation_A4.py
"""

from datetime import datetime, timedelta
import pytest

from ablation_A4 import (
    Disposition,
    Finding,
    LeafGrant,
    LeafAction,
    RootCampaignAuthority,
    route_q_decision,
    ablated_no_rescue,
    ablated_rescue_P1_stricter_evidence,
    ablated_rescue_P5_revalidation,
    ablated_rescue_P6_flag_then_execute,
    ablated_rescue_native_rate_cap,
    a2l_strong_peer_decision,
    NOW,
)

FAR_FUTURE = NOW + timedelta(days=30)
CAMPAIGN_REF = "SOLSTICE-PRICING-FAULT-2026-09"


def make_finding(accounts=4000, exposure=240_000.0) -> Finding:
    return Finding(
        affected_accounts=accounts,
        aggregate_exposure=exposure,
        reconstructable_from_authorized_reads=True,
    )


def make_leaf_actions(n: int, campaign_ref, start=NOW) -> list[LeafAction]:
    """n individually-valid, individually-capped refund actions, each one
    case, each timestamped seconds apart -- exactly as V1a describes:
    'each low-value refund request is accepted by the payment layer.'"""
    actions = []
    for i in range(n):
        grant = LeafGrant(
            case_id=f"CASE-{i:05d}",
            cap_amount=50.0,
            campaign_ref=campaign_ref,
            expiry=FAR_FUTURE,
        )
        actions.append(
            LeafAction(
                account_id=f"ACCT-{i:05d}",
                amount=40.0,
                grant=grant,
                timestamp=start + timedelta(seconds=i),
            )
        )
    return actions


# ---------------------------------------------------------------------------
# ROUTE Q -- all six principles intact (the requirements-conforming route)
# ---------------------------------------------------------------------------

def test_route_q_blocks_branch_U_unauthorized_campaign():
    """Branch U: leaf grants valid, common root present, root authority ABSENT.
    Route Q must preserve the finding and NOT execute the composed campaign."""
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)
    registry = {}  # no root campaign authority exists for CAMPAIGN_REF
    result = route_q_decision(finding, actions, registry)
    assert result == Disposition.DBC_REPOSITION_RECONTRACT


def test_route_q_allows_branch_G_genuinely_authorized_campaign():
    """Branch G: same topology, but root campaign authority is valid and
    current. Route Q must NOT blanket-freeze this -- it is the positive
    control that rules out a deny-all disguised as a fix."""
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)
    registry = {
        CAMPAIGN_REF: RootCampaignAuthority(
            campaign_ref=CAMPAIGN_REF, issuer="Solstice-Finance-Ops", valid=True, expiry=FAR_FUTURE
        )
    }
    result = route_q_decision(finding, actions, registry)
    assert result == Disposition.DBC_EXECUTE


def test_route_q_allows_branch_I_genuinely_independent_cases():
    """Branch I: no shared campaign root at all -- ordinary, unrelated
    single-case work. Must proceed normally, not be treated as a campaign."""
    finding = make_finding(accounts=150, exposure=12_000.0)
    actions = [
        LeafAction(
            account_id=f"ACCT-{i}",
            amount=40.0,
            grant=LeafGrant(case_id=f"CASE-{i}", cap_amount=50.0, campaign_ref=None, expiry=FAR_FUTURE),
            timestamp=NOW + timedelta(minutes=i),
        )
        for i in range(3)
    ]
    result = route_q_decision(finding, actions, {})
    assert result == Disposition.DBC_EXECUTE


def test_route_q_denies_non_material_finding():
    """Negative control on P1 itself: a trivially small finding must not
    even reach the campaign question."""
    finding = make_finding(accounts=2, exposure=11.0)
    actions = make_leaf_actions(2, CAMPAIGN_REF)
    result = route_q_decision(finding, actions, {})
    assert result == Disposition.DBC_DENY


# ---------------------------------------------------------------------------
# ABLATION A4 -- P4 removed. Four genuine rescue attempts, each tested
# against BOTH Branch U (must stay blocked) and Branch G (must stay allowed).
# A rescue only counts as a TRUE SUBSTITUTE if it gets both right.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "rescue_fn",
    [ablated_no_rescue, ablated_rescue_P1_stricter_evidence,
     ablated_rescue_P5_revalidation, ablated_rescue_P6_flag_then_execute],
)
def test_ablated_rescues_wrongly_execute_branch_U(rescue_fn):
    """FAILED SUBSTITUTE: none of P1, P5, or P6-without-P4 can tell that
    this specific campaign lacks root authority, because none of them
    ever look at root authority. Each wrongly executes Branch U."""
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)
    result = rescue_fn(finding, actions)
    assert result == Disposition.DBC_EXECUTE, (
        f"{rescue_fn.__name__} unexpectedly blocked Branch U without any "
        f"root-authority check -- inspect whether it silently reconstructed P4."
    )


def test_ablated_native_rate_cap_blocks_branch_U():
    """The rate cap DOES stop Branch U -- 4,000 actions/hour exceeds any
    realistic cap. On its own this looks like a rescue."""
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)
    result = ablated_rescue_native_rate_cap(finding, actions, max_per_hour=10)
    assert result == Disposition.DBC_DENY


def test_ablated_native_rate_cap_ALSO_blocks_branch_G():
    """The deny-all trap, demonstrated: the SAME cap, at the SAME threshold,
    also blocks Branch G -- a campaign that IS root-authorized -- because
    the cap has no way to see root authority at all. This is exactly the
    00K 'no deny-all shortcut' failure: it is not a rescue, it is blindness
    that happens to overlap with the right answer on one branch only."""
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)  # same volume as Branch G would have
    result = ablated_rescue_native_rate_cap(finding, actions, max_per_hour=10)
    assert result == Disposition.DBC_DENY, (
        "If this ever starts passing (DBC_EXECUTE), the rate cap has been "
        "given some way to see root authority -- i.e., it has reconstructed P4."
    )


def make_NM_case() -> tuple[Finding, list[LeafAction]]:
    """00K-A03's NM branch, verbatim: 2 accounts / USD 11, below 00H-MAT-1.
    Independently arrived at with the same numbers as the paper execution."""
    finding = make_finding(accounts=2, exposure=11.0)
    actions = make_leaf_actions(2, CAMPAIGN_REF)
    return finding, actions


@pytest.mark.parametrize(
    "fn",
    [ablated_no_rescue, ablated_rescue_P1_stricter_evidence,
     ablated_rescue_P5_revalidation, ablated_rescue_P6_flag_then_execute],
)
def test_NM_no_unnecessary_escalation_ablated_arms(fn):
    """NM overreaction control, run across the ablated arms too: a trivially
    small, non-material finding must not trigger action or escalation
    anywhere in the ablated system either."""
    finding, actions = make_NM_case()
    assert fn(finding, actions) == Disposition.DBC_DENY


def test_NM_native_rate_cap_no_unnecessary_escalation():
    finding, actions = make_NM_case()
    assert ablated_rescue_native_rate_cap(finding, actions) == Disposition.DBC_DENY


def test_NM_a2l_no_unnecessary_escalation():
    finding, actions = make_NM_case()
    assert a2l_strong_peer_decision(finding, actions, {}) == Disposition.DBC_DENY


# ---------------------------------------------------------------------------
# A2-L (00K-A03 R6): a non-EA-branded strong peer that reconstructs P4's
# invariant under its own name. Must pass U, G, I and NM -- and does, because
# mechanically it computes the same root-authority fact route_q_decision does.
# ---------------------------------------------------------------------------

def test_a2l_blocks_branch_U():
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)
    result = a2l_strong_peer_decision(finding, actions, {})
    assert result == Disposition.DBC_REPOSITION_RECONTRACT


def test_a2l_allows_branch_G():
    finding = make_finding()
    actions = make_leaf_actions(4000, CAMPAIGN_REF)
    ledger = {CAMPAIGN_REF: RootCampaignAuthority(CAMPAIGN_REF, "Solstice-Finance-Ops", True, FAR_FUTURE)}
    result = a2l_strong_peer_decision(finding, actions, ledger)
    assert result == Disposition.DBC_EXECUTE


def test_a2l_keeps_branch_I_independent():
    finding = make_finding(accounts=150, exposure=12_000.0)
    actions = [
        LeafAction(f"ACCT-{i}", 40.0, LeafGrant(f"CASE-{i}", 50.0, None, FAR_FUTURE), NOW + timedelta(minutes=i))
        for i in range(3)
    ]
    assert a2l_strong_peer_decision(finding, actions, {}) == Disposition.DBC_EXECUTE


# ---------------------------------------------------------------------------
# Four-arm comparison, matching 00K-A03 §10 exactly:
#   1. -P4 leaf/local baseline
#   2. -P4 + strongest non-lineage repair (native rate cap)
#   3. A2-L semantic-reconstruction peer
#   4. full six-principle / requirements-conforming comparator (Route Q)
# ---------------------------------------------------------------------------

def test_four_arm_comparison_table():
    finding = make_finding()
    actions_U = make_leaf_actions(4000, CAMPAIGN_REF)
    ledger_G = {CAMPAIGN_REF: RootCampaignAuthority(CAMPAIGN_REF, "Solstice-Finance-Ops", True, FAR_FUTURE)}

    arms = {
        "1_baseline_no_lineage": lambda: ablated_no_rescue(finding, actions_U),
        "2_strongest_non_lineage_repair": lambda: ablated_rescue_native_rate_cap(finding, actions_U),
        "3_A2L_semantic_reconstruction": lambda: a2l_strong_peer_decision(finding, actions_U, {}),
        "4_route_q_full_six_principles": lambda: route_q_decision(finding, actions_U, {}),
    }

    results_on_U = {name: fn() for name, fn in arms.items()}

    print("\n--- Four-arm comparison on Branch U (unauthorized campaign) ---")
    for name, result in results_on_U.items():
        print(f"  {name:35s} -> {result.value}")

    # Only arms with root/delegation lineage (3 and 4) correctly refuse to
    # execute the unauthorized campaign.
    assert results_on_U["1_baseline_no_lineage"] == Disposition.DBC_EXECUTE  # wrong
    assert results_on_U["2_strongest_non_lineage_repair"] == Disposition.DBC_DENY  # blocks, but blindly (see G below)
    assert results_on_U["3_A2L_semantic_reconstruction"] == Disposition.DBC_REPOSITION_RECONTRACT  # correct
    assert results_on_U["4_route_q_full_six_principles"] == Disposition.DBC_REPOSITION_RECONTRACT  # correct

    # Now re-run arms 2-4 on Branch G (same volume, but root-authorized) to
    # show which ones are blind versus genuinely discriminating.
    arms_G = {
        "2_strongest_non_lineage_repair": lambda: ablated_rescue_native_rate_cap(finding, actions_U),
        "3_A2L_semantic_reconstruction": lambda: a2l_strong_peer_decision(finding, actions_U, ledger_G),
        "4_route_q_full_six_principles": lambda: route_q_decision(finding, actions_U, ledger_G),
    }
    results_on_G = {name: fn() for name, fn in arms_G.items()}

    print("--- Same four arms on Branch G (genuinely authorized campaign) ---")
    for name, result in results_on_G.items():
        print(f"  {name:35s} -> {result.value}")

    assert results_on_G["2_strongest_non_lineage_repair"] == Disposition.DBC_DENY  # deny-all trap: blocks G too
    assert results_on_G["3_A2L_semantic_reconstruction"] == Disposition.DBC_EXECUTE  # correctly discriminates
    assert results_on_G["4_route_q_full_six_principles"] == Disposition.DBC_EXECUTE  # correctly discriminates


def test_true_substitute_not_found_among_tested_rescues():
    """Summary assertion: across all five tested rescue attempts (P1, P5,
    P6-flag-only, no-rescue, and a realistic native rate cap), not one
    achieves TRUE SUBSTITUTE status (correct on both Branch U and Branch G
    without referencing root authority). This does not prove no true
    substitute can ever exist -- only that none was found among the
    plausible candidates tested here."""
    finding = make_finding()
    actions_U = make_leaf_actions(4000, CAMPAIGN_REF)

    rescues_that_get_U_right = {
        "native_rate_cap": ablated_rescue_native_rate_cap(finding, actions_U) == Disposition.DBC_DENY,
    }
    rescues_that_also_get_G_right = {
        "native_rate_cap": False,  # proven wrong in the test above -- it blocks G too
    }
    true_substitutes = [
        name for name in rescues_that_get_U_right
        if rescues_that_get_U_right[name] and rescues_that_also_get_G_right.get(name, False)
    ]
    assert true_substitutes == [], f"Unexpected true substitute(s) found: {true_substitutes}"
