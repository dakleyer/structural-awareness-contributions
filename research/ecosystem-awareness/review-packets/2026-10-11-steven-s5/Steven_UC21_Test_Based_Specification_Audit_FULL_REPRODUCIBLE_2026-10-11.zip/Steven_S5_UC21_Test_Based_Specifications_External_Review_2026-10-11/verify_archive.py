#!/usr/bin/env python3
"""Verify all immutable distributed input/results of this review bundle."""
from __future__ import annotations
import hashlib
from pathlib import Path

root=Path(__file__).resolve().parent
manifest=root/'MANIFEST_SHA256.txt'
if not manifest.is_file():
    raise SystemExit('ERROR: MANIFEST_SHA256.txt absent')
count=0
for raw in manifest.read_text().splitlines():
    if not raw.strip():continue
    expected,rel=raw.split('  ',1)
    path=root/rel
    if not path.is_file():raise SystemExit('MISSING: '+rel)
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:raise SystemExit(f'INTEGRITY FAIL: {rel}; expected {expected}, got {actual}')
    count+=1
print(f'ARCHIVE INTEGRITY PASS: {count} files matched their registered SHA-256 digests')
