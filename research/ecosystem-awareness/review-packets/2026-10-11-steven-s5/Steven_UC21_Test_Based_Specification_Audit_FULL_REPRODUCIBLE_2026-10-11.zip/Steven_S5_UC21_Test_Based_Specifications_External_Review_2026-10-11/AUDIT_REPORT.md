# Independent-review-ready technical audit dossier — Steven Zhao's S5 runnable contribution

**Study:** UC-21 · S5 / 00I · AWS Step Functions–RDS documentary trajectory · DDS test-based specification discovery  
**Cut-off:** 11 October 2026  
**Status:** **SECOND-PASS, EXECUTED, REVIEWER-CONTROLLED TECHNICAL AUDIT; EXTERNALLY REVIEWABLE, NOT AN EXTERNAL AUDIT OPINION**  
**Code owner:** Xinghua (Steven) Zhao — `@zhaoxinghua09-cell`  
**Reviewed commit:** `b59a686b887c2a2545dd22808fb67e629bc95f18`  
**Object actually exercised:** author's original `examples/S5-Qregister/implementation.py` (Git blob `4dd9ace3de82ca0ced126656a9f1fa9867bba1f4`), with its original `fixture_spec.json` (Git blob `3801dfd50a59d9b54650361fcab8fed5ebfcdc6c`).  
**Review authority:** research-side critical examination and newly authored diagnostic harness; **neither Steven's approval nor Nelson's experimental admission is inferred**.  
**Versions:** this report supersedes the earlier 18-case audit **only in interpretation and added tests**; the earlier independent review text and raw record are preserved as unchanged historical appendices.

---

## 1. Executive determination

**The positive result is real and should lead the discussion.** Steven has produced executable code, not merely a design paper: two runnable diagnostic examples, a six-branch S5 decision model with explicit attempts, a separate stateful synthetic target, synthetic negative controls, mutation/checker tests, and a seriously iterated review process. The existing source is an independently inspectable and falsifiable research contribution. The crosswalk, two-factor Patch-B/freeze split, Q6 timestamp derivation, final guard/exit recomputation, and distinction among different mutation types are meaningful engineering advances. His code sits at a *more implemented evidence level* than our documentary AWS-I0/I1/I2 design; that advantage must receive credit.

**The central reservation is narrower than a blanket criticism.** In `I2-complete`, the executable decision path still reports PASS for some S5 gates without computing the corresponding wider S5 predicates. Seven earlier reviewer-specified variants (plus an additional ill-formed-timeline probe in this second pass) leave the full decision trace identical to clean continuity even when authority, version/freshness, present generation or declared binding information is altered. The owner explicitly states that the reference completeness and deep Q3 freshness are stipulated or outside this small model. Such results demonstrate **non-coverage** of certain broader claims. They do **not** invalidate the six published scenario results, demonstrate a production AWS defect, or prove that an architecturally necessary mechanism is missing in all possible implementations.

This second pass adds:

- A fresh, direct Git-blob integrity check against the exact, unmodified source and fixture, together with a structural AST check of observed-data reads.
- Re-execution of the **18 existing** focused cases and **15 new reviewer-controlled targeted variations** (some overlap intentionally), including correct positive outcomes and explicit negative controls.
- A full-factorial, **6,480-synthetic-combination sensitivity census** of the standalone decision path, archived at row level in CSV, establishing decision/trace invariance to four supplied metadata fields *conditional on the other routing inputs*. **The 6,480 combinations are not 6,480 physically admissible, independent semantic tests**; many contain mismatched assumptions. Their use is to corroborate code dependency and expose hidden conditioning, not to award a pass score.
- Negative controls against **our own** test procedure: deliberate false expected output, modified code byte, modified fixture byte, an always-execute dummy, and a deny-all dummy. The checks reject or identify the faulty inputs as intended.
- Explicit correction of a version-count mistake in the earlier dossier: the pinned commit's `.github/workflows/gates.yml` has **16 numbered gates** (Git blob `b38412a63a54b1e33d62ba74209dd365ef49c72d`); **17 gates** is a distinct later workflow state, not evidence at this freeze. The count must follow its named pin.

**Final scope disposition:** `BOUNDED_EXECUTABLE_MODEL_SUPPORTED; BROADER_S5_Q0_Q6_COVERAGE_NOT_ESTABLISHED; INDEPENDENT_TARGET_EFFECT_NOT_ESTABLISHED; R1_R2_NOT_ESTABLISHED; NATIVE_AWS_NOT_TESTED; UC4_CAMPAIGN_NOT_ADMITTED`. This is a claim-by-claim ceiling, not a rejection of the implementation and not an FG-TIDA standards disposition.

## 2. Why we are conducting this study: test-based specification discovery

The research process is intentionally **test-based specification discovery**, not a competition designed to reward an Ecosystem Awareness (EA) architecture. A frozen *Challenge* identifies a decision or action whose local technical checks can succeed while the relying system's combined evidence becomes insufficient. In UC-21, six distinct scenario families—S1 through S6, including the S5 delayed database repair—provide candidate failure mechanisms. The S5/T08 case asks whether a queued repair remains authorized, justified and temporally bound when it is actually executed.

The test-based cycle is:

1. Freeze a business-relevant failure predicate, positive continuity and the actors' legally/technically available evidence. Do not derive the test solely from a preferred solution.
2. Credit an existing competent conventional mechanism when it satisfies the frozen requirements within matched source access, human effort, latency and cost.
3. Test bounded diagnostics, counterexamples and, where admitted, architecture and implementation experiments. Determine **what can be observed, what must be represented, what must trigger requalification, and what effects are prevented**.
4. Register limitations, inconclusiveness and successful conventional defences as results. Do not force every experiment to produce a new requirement or EA advantage.
5. **Only after the agreed experimental question is closed**, convene a suitably distinct specification-review step to ask which technical requirements, if any, merit being advanced as draft UC-21/DDS inputs and potentially FG-TIDA work items.

DDS distinguishes specification discovery (**Stage A**), architecture verification (**Stage B**) and pinned implementation/problem validation (**Stage C**). Having executable Python is valuable, but does not automatically mean Stage C, proof of native AWS behavior or formal endorsement of an architecture. The future mapping from candidate requirements into FG-TIDA materials is **proposed pre-standardization work**—the group's published Terms of Reference provide deliverable categories, not automatic approval of these findings. See §11.

## 3. Exact evidence levels and source registry

| ID | Artifact or finding | Verifiable identity | Status in this review |
|---|---|---|---|
| Z1 | S5 `implementation.py` | [pinned source](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister/implementation.py), blob `4dd9ace3de82ca0ced126656a9f1fa9867bba1f4` | **Bundled exactly; imported and run** |
| Z2 | S5 `fixture_spec.json` | [pinned fixture](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister/fixture_spec.json), blob `3801dfd50a59d9b54650361fcab8fed5ebfcdc6c` | **Bundled exactly; hash and dispositions checked** |
| Z3 | S5 author's `harness.py` | [pinned harness](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister/harness.py), blob `3e4aa94b3278bbd0a23297b2a225a5d3bd2877c9` | Source inspected directly, **not bundled or executed in this offline reviewer archive** |
| Z4 | Separate T08 four-case companion | [pinned simulation](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/T08-S5Q2/simulation.py), blob `2dfa54f737e61c2892442e775a3fd6251ef05600` | Source inspected, **not run** |
| Z5 | 16-step `gates.yml` at frozen pin | [pinned workflow](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/.github/workflows/gates.yml), blob `b38412a63a54b1e33d62ba74209dd365ef49c72d` | **Source inspected, not independently executed** |
| Z6 | Mutation scorer | [pinned source](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/tools/impl-mutation.py), blob `208fc6978244454098c194521bf1a3ebdf00049b` | **Source inspected, not independently executed** |
| Z7 | Mutation negative-control suite | [pinned source](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/tools/impl-mutation-negctl.py), blob `78c76d60cd147b634a56576ea9a263592594f94d` | Present, but **not an independently named invocation in the pinned CI workflow**; not locally executed |
| U1 | UC-21 frozen original | [UC-21](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/USE_CASE.md) | Normative challenge **reference**, not a product execution |
| U2 | UC-21 S5 local conditions | [S5 annex Q0–Q6](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/annexes/scenarios/S5.md#7-scenario-local-acceptance-register) | Reference for broader semantic predicates |
| U3 | UC-21 T08 AWS design | [technology annex T08](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/annexes/technology/T08.md) | **Documentary** AWS-I0/I1/I2 comparison; not the same as Steven I0/I1/I2 |
| N1 | Nelson's UC-4 experimental role | [proposal](https://github.com/FG-TIDA/use-cases/issues/4#issuecomment-5846988611), [S5 requirements](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-5936720586), [later UC-4 proposal](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-6089067288) | Proposals; **not an admitted or executed campaign** |
| T1 | Official FG-TIDA ToR | [ITU-T Terms of Reference](https://www.itu.int/en/ITU-T/focusgroups/tida/Pages/ToR.aspx) | Scope/deliverable categories; **not approval of this study** |

**Preservation:** `upstream/implementation.py`, `upstream/fixture_spec.json` and `upstream/LICENSE.txt` are the untouched source-owned code/metadata. The reviewer scripts are distinctly named under `audit/`. Because fetching the full online repository is not required to run the local audit, the ZIP is offline-executable; it does **not** masquerade as a reconstructed upstream Git clone.

## 4. What was actually executed

### 4.1 Replayed 18-case reviewer baseline

Six clean `I2` cases cover legitimate continuity, known Patch B, known active freeze, both causes with trace preservation, known source unavailability and a supplied in-window freeze-effective timestamp. I0/I1 negative demonstrations are reproduced separately. Seven altered-field probes return the same `EXECUTE/APPLY` decision and the exact same gate trace as clean continuity. One additional future freeze *after* action correctly leaves continuity unchanged. Two epistemic controls distinguish unknown information from information supplied to the candidate.

Exact case IDs, structured observations, full gate lines and verdicts are in `records/previous_focused_18.json` and `audit/run_focused_18.py`. A 'matching prediction' means this diagnostic reproduced the observed module behavior; it does **not** mean the candidate passed the broader S5 obligation.

### 4.2 Second-pass targeted cases

| Probe group | Input changed from clean control | Actual I2 observation | Supported inference / what it cannot infer |
|---|---|---|---|
| Q0 authority | revocation; wrong principal | `EXECUTE/APPLY`, unchanged full gate trace | The module does not enforce those **additional** authority-state distinctions; the published six-case scope assumes valid authority |
| Q3 source provenance/freshness | different `source_version`; old `observed_at` | `EXECUTE/APPLY`, unchanged trace | No version/freshness computation in this decision path; source completeness and deep Q3 intentionally stipulated by owner |
| Q4 state/lineage | generation changes but lineage remains empty | `EXECUTE/APPLY`, unchanged trace | This module trusts supplied lineage; a fully honest upstream collector could prevent that input inconsistency, which this audit does not test |
| Q6 binding | empty `binding_tokens`; missing `t_act`; nonmonotonic times | `EXECUTE/APPLY`, unchanged trace | No substantive binding-token validation or missing/ill-ordered clock rejection; those variants lie outside original complete-frozen input contract |
| Time positive | supplied freeze inside interval; exactly at either endpoint | `BLOCK_BOUNDARY/NONE` | Correct inclusive comparison **given the supplied observation** |
| Time negative | freeze becomes effective after action | `EXECUTE/APPLY` | Not a deny-everything model; avoids blocking an irrelevant future freeze |
| Other author-positive | explicitly unavailable source; known supersession; active freeze | HOLD / REASSESS / DENY as registered | The illustrated subset's important defensive decision branches execute |

No experimentally independent human authority source, database event, AWS target or material context-discovery process was exercised.

### 4.3 6,480-factor synthetic sensitivity census: what it does and does not establish

The complete, reproducible CSV enumerates:

- `authority_state` × 3 (declared valid / revoked / wrong scope);
- `current_generation` × 3;
- `source_version` × 3;
- `binding_tokens` × 3;
- `source_available` × 2;
- `supersession_lineage` × 2;
- `freeze_state` × 2;
- temporal observation frames × 10.

Total: \(3^4 \times 2^3 \times 10 = 6{,}480\) synthetic calls to **the unchanged original decision function**. Source AST reads independently confirm which fields are used.

| Observed guard | Synthetic combinations |
|---|---:|
| `HOLD_ESCALATE` | 3,240 |
| `BLOCK_REASSESS` | 1,620 |
| `DENY` | 810 |
| `BLOCK_BOUNDARY` | 243 |
| `EXECUTE` | 567 |
| **Total** | **6,480** |

Within each of 80 combinations of other routing inputs (source availability, lineage, freeze-state, and 10 timestamp frames), 81 combinations of authority, generation, version and binding-token values have **identical** decision/action/**entire gate-trace** signatures. The recorded census therefore has **zero metadata-sensitive routing groups**. This is a useful falsifiable characterization of the decision module's dependency structure.

**Crucial limitation:** no evidence basis says that all 6,480 combinations represent admissible physical worlds. Some contain contradictory version/authority/lineage/time fields by design. A model with a well-defined external observation contract could lawfully reject them *before* this function. The census cannot adjudicate such an upstream validator that is not part of the tested module. **It establishes invariance and a need to distinguish asserted coverage from enforced predicates, not 6,480 operational vulnerabilities.**

### 4.4 Tests of the tests

The independent auditor program intentionally feeds a false expectation, a one-byte modified source, a one-byte modified fixture, and two always-accept/always-deny diagnostic substitutes to the *reviewer-controlled checks*. They are rejected or detected, as documented in `records/audit_result.json`. This is meaningful but limited: it verifies several gross failure modes of **our** runner, not source-owner CI equivalence, oracle-authoring independence or completeness of the test suite. The original review 18-case runner had its own false-prediction and source-pin selftests; both are preserved separately.

## 5. Detailed Q0–Q6 finding matrix, including fair scope boundaries

| Gate | S5 challenge predicate | Actual executable evidence in Steven I2 | Assumption or unsupported extension | Disposition |
|---|---|---|---|---|
| **Q0** | Grant current, unrevoked, and bound to legitimate subject and scope | Emits `CONTROL_EXECUTED_PASS`, but `authority_state` is not read | Valid grant must be supplied/enforced externally | **Non-enforcement in tested module confirmed**; *not* a violation of an explicitly claimed revoked-grant fixture |
| **Q1** | Material decision basis and intervening facts independently reconstructable | Emits an affirmative textual gate line; no full incident/diagnosis/history structure in the I2 function | Upstream ledger and completeness presumed | **Full reconstructability not exercised** |
| **Q2** | Preconditions re-evaluated at time of use from legitimate observations | Decisions depend on supplied state and time inputs | Source acquisition and event-time knowledge outside the function | **Limited logic exercised**; *real re-acquisition not proven* |
| **Q3** | Source identity, authorization, version, age/freshness within declared bound | Tests `source_available`; does not read `source_version` or `observed_at` as a validity constraint | Freshness represented as Boolean and deep Q3 excluded in README/spec | **Broader Q3 not exercised; declared model limit** |
| **Q4** | Current changes to generation or later interventions invalidate an obsolete basis | Tests supplied `supersession_lineage`; separate freeze input; maintains both-reasons trace | Source-derived lineage consistency may be guaranteed by an external actor that is not tested | **Works if lineage complete; independent generation check not established** |
| **Q5** | Scoped and timely response; unknown not permission; legitimate unaffected activity continues | HOLD on `source_available=False`; continuation allowed on clean case; escalation owner/deadline text logged | No human ack, response completion, monitor, resource accounting or unaffected parallel unit measured | **Bounded response outcome claimed textually, not operationally demonstrated** |
| **Q6** | Observed state bound through actual action; fail or reopen after material change | Derives breach when supplied `t_check <= t_freeze <= t_act`; includes both endpoints | No knowledge/acquisition clock; `t_freeze` is already supplied to one observation; no separate runtime recheck; empty binding tokens unused | **Supplied-event interval discrimination supported; real unannounced event handling and atomic action binding not established** |

**Semantic guardrail:** It would be unfair to say Steven *promised* live AWS permission checks, actual human escalation and clock-skew-resistant source discovery in this illustrative module. His README discloses model-only status and bounded Q3/reference assumptions. A legitimate outcome is to improve **claim wording** or to close at the documented scope. Implementing every full S5 gate is necessary only if those stronger gates are proposed as executable evidence claims.

## 6. Independent effect, temporal knowledge, reference completeness and mutation review

### 6.1 Effect readback is structurally separate but causally deterministic

The source-owned `harness.TargetModel` is **not** imported or queried by `implementation.py`. `actuate()` writes `QUEUED_REPAIR_GENERATION` and increments `actuations` for every `ACTION_APPLY`; `probe_target_state()` compares pre/post snapshots. That is a genuine distinct output channel, and we credit it. However, `_assert_observation_coherence()` imposes `target_changed == (action == ACTION_APPLY)` (source-visible lines 461–512). Thus the author's model does not naturally retain *failed write*, *partial write*, *delayed effect*, *bypass writer* or an independent customer-facing `F_I` deterioration as ordinary observations. None of those was executed in this ZIP. Any extension must keep the original six cases intact, introduce an externally specified service-impact predicate, and record attempt, target effect and business effect separately.

### 6.2 The knowledge timestamp question is not answered by passing Q6

The source-owned `observables_for('act-window')` supplies `t_check=1700000000`, `t_freeze=1700000005`, `t_act=1700000009` **before** the I2 decision is called. The implementation correctly recognizes the interval, and a future-effective freeze may in reality be known before its effective time—so calling this necessarily 'future leakage' would be unfounded. What it does **not** demonstrate is discovery of an *unannounced* event without an actual re-observation step. A fair future experiment must preregister `known_to_actor_at`, `event_effective_at`, `observation_acquired_at`, `decision_clock`, `action_clock`, then compare scheduled-known and genuinely unannounced events without handing the initial guard inaccessible data.

### 6.3 Completeness of the source set and the strong conventional comparator

The owner's fixture explicitly stipulates the applicable source set. When both candidate and reference omit the same material dependency, a simple source-difference comparison cannot discover the omission. This is a **boundary of the stipulated fixture**, not proof that all real configurations fail discovery. Our own `00I-STATEFUL` line separately reports a conventional dynamic-manifest strategy that **passes** the declared D1 source-set drift; that outcome must be credited and not replaced by a story in which EA inherently wins.

Steven's local `I1-defended` is intentionally defective (stale cache / missing lineage); it is not UC-21's **strong corrected R1**. His `I2-complete` is his local complete branch, **not** the same frozen R1 subjected to UC-21's independent R2 source/policy/dependency change. No R2 recurrence conclusion follows here. The 00I and Steven test harnesses have different input objects and oracles and cannot be pooled without a frozen crosswalk.

### 6.4 Mutation instrumentation deserves credit, with bounded meaning

The pinned mutation scorer reflects Nelson's earlier objections: timeout kills are counted once, non-exempt survivors fail regardless of a numerical threshold, and sentinel accounting was corrected. The source-owner testbed has author-maintained checks of the checker, case-to-crosswalk consistency, and regression tests for known maskings. This is substantive technical work, not decoration.

Two caveats remain:

- A mutation score measures detection of the *selected mutations* under the authored fixtures. It cannot prove the wider Q0/Q3/Q4/Q5/Q6 conditions that the candidate does not implement or the author intentionally excludes.
- At exact pin `b59a686...`, `.github/workflows/gates.yml` shows 16 numbered gates; `tools/impl-mutation-negctl.py` is a separate available tool but not listed as an independently named workflow invocation. This is a traceable automation/claim boundary, not proof it never runs in some other path. Later workflow versions showing 17 steps are not identical evidence objects.

### 6.5 Blinding and oracle authorship

The harness hides branch labels from the ordinary `Observation` interface; `_assert_blind` scans executable content for literal branch names and listed escape paths. The author explicitly corrected an earlier claim that module separation alone eliminates hidden access. This is a positive example of an adversarial review changing an implementation claim. The scanner is **pattern-based**; it is not a formal sandbox against arbitrary adversarial imports or covert channels. The reviewer expected outputs and the synthetic target behavior remain within a shared authoring lineage; external test-source oracles are still needed for a genuinely independent comparative verdict.

## 7. Second-pass corrections to the original review

The previous 18-case report is retained unaltered in `appendices/`, but reviewers should read the following corrections **first**:

1. **CI version identity.** Earlier text said “17 gates” while citing `b59a686...`. Directly inspected frozen `gates.yml` has **16 numbered steps**; 17 belongs to another later workflow revision. Always quote the count beside the exact commit.
2. **Seven non-enforcement probes are not seven native test failures.** The seven changed-field records establish behavioral invariance in `implementation.py`. Some inputs are expressly excluded (`Q3` deep freshness) or would be inconsistent under a complete upstream observation contract (Q4 missing lineage, Q6 missing timestamp). Label them **scope/correspondence findings**, not security exploits or broken six-branch fixtures.
3. **Target-channel language.** Source-owned target readback is genuinely separate from the decision function; calling it 'self-reported' is wrong. Its causal success is deterministic by fixture design, so independent *operational* effect is still missing.
4. **Q6 knowledge nuance.** A supplied effective-time instant may be legitimately announced. Distinguish 'future known event' from 'unannounced event learned only later'. No hindsight accusation without a clock/admissibility model.
5. **Checker limits symmetrical.** Our 18-case oracle was reviewer-authored and our 6,480-point grid deliberately contains counterfactual worlds. Neither warrants a claim of an independently authored *business effect* oracle or a statistical accuracy measure. The review code and artifacts are subject to the same external challenge requested of Steven.
6. **Author's testing strengths.** Steven's source code, CI, hash manifest discipline, crosswalk consistency work, mutation negative controls and repaired blinding must be recorded as real strengths; our test-based specification discovery study should learn from them, not misframe their existence as a problem.

## 8. Experimental options and stopping points

### Option A — close the bounded runnable contribution now

If Steven confirms its described scope, an acceptable result is a finished, executable six-branch S5 diagnostic **with these explicit assumptions**: authority supplied as valid; reference completeness stipulated; freshness abstracted to availability; transition lineage supplied; interval timestamps available to the Q6 function; effects are deterministic model effects. `Q0/Q1/Q3/Q5` affirmative trace language can be bounded in the README without requiring new architectural development. This closes the **model-level example**, not all UC-21, not Stage B/C, and not R2.

### Option B — admit exactly one experimental successor if its value justifies it

Nelson's UC-4 proposal is the appropriate decision gate, **if he agrees**: he would decide what can be implemented/observed, estimate resources, agree cases and controls with owners, lead execution and comparative analysis, and recommend when the agreed question is sufficiently answered. Do **not** assign him an independent auditor certification merely because he leads the work. If a signed independent audit opinion is required, appoint an additional independent adjudicator or rerun reviewer.

The minimum reasonable first S5 test is a fully valid strong R1 *Patch-B supersession* plus legitimate-continuity pair, with independent expected target-effect reading, G1/G4 controls separated, and matched inputs/resources for a conventional peer. Only a strong corrected frozen R1 may then be considered for preregistered D1/R2. His **single pinned catalog-entry UC-4 adapter request**, Steven's two runnable S5 examples and Matías's separate CDA package remain **different candidates**; a successful adapter schema validation is not S5 target-effect execution.

Nelson should propose `CLOSE_BOUNDED`, `INCONCLUSIVE/NOT_EVALUABLE` or `ONE_SUCCESSOR_ADMITTED_WITH_RESOURCES` (plus named independent-review requirements), preserving any dissent. Never let the number of possible tests become the research objective.

## 9. Candidate specification implications — explicitly **not yet adopted**

These are research questions, not accepted specifications or mandatory implementation components:

| Candidate question | Would the evidence support a requirement? | What further test would discriminate? |
|---|---|---|
| Q0 current authority | Not from Steven's current six branches alone | Valid/revoked/wrong-principal/wrong-scope variations with a separately controlled authorization source |
| Q3 freshness/reference trust | Not from an availability Boolean alone | Fresh-but-wrong-source; available-but-stale; positive normal reads with published acquisition/freshness contract |
| Q4 supersession/current generation | Branch with declared lineage works | Unknown/incomplete lineage separated from current generation, with explicit collector/source ownership and no post hoc oracle edits |
| Q5 proportionate response | HOLD label and clean positive are useful but insufficient for end-to-end response | Acknowledged escalation, deadlines, effect and continuity of unrelated work within resources |
| Q6 action binding | In-window timestamp inference works | Preregister scheduled-known versus initially unannounced events, then independent action-boundary readback |
| Source-set change | Not tested as a new source discovery here | Matched, frozen strong peer with dynamic manifest; **credit a successful conventional D1** |
| Outcome fidelity | Deterministic target changed/unchanged channel is useful | Failed/partial/delayed/bypass writes and independently authored `F_I` (service recovery or deterioration) |

The subsequent specification review may conclude that some existing mechanisms already suffice, that a proposed EA requirement should be **deleted**, or that a narrower mechanism-neutral requirement is justified. The review should be performed after the bounded experiment ends and preferably by a broader group than the implementation author and test designers.

## 10. Fully reproducible package and independent-review instructions

This ZIP contains the original pinned `implementation.py` and `fixture_spec.json`, an explicit MIT license, independently authored scripts, the source-pin register, pre-generated output and its SHA-256 manifest. It uses **Python 3.9 or newer**, standard library only; no private connectors, ChatGPT conversations or internet access are needed for the local tests. The upstream original full harness, T08 model, product integration and remote CI are **not embedded or represented as already executed**.

Unzip into a directory, then:

```sh
python3 verify_archive.py
python3 run_all.py
```

`run_all.py` verifies distributed evidence, executes the existing 18-case review, performs AST analysis and the 6,480-row synthetic sensitivity census, runs the new negative controls and saves a complete `replay/` directory. For the most detailed source/trace review, inspect `records/` (archived) and `replay/` (your own run). No new source file is silently treated as Steven's code. The bundle deliberately refuses to run if its vendored original code/fixture is edited.

A reviewer with internet access wishing to reproduce **Steven's original full selftests and CI** must separately obtain the entire repository at the pinned commit. The exact commands are in `README.md`; this is a separate procedure with separately captured outputs and must not be conflated with the shipped offline review results. To judge a newer Steven revision, create a **new audit pin and a new result set**, without overwriting these.

### Third-party audit checklist

- Verify upstream blob hashes and supplied archive manifest; record reviewer name, affiliation, conflict disclosures, interpreter/environment and exact commands.
- Replay both instruments. Inspect negative controls and the 15 counterfactual variants, including which are outside the author's published input assumptions.
- Independently derive at least one competing expected result from the UC-21 challenge, not from `implementation.py` nor the same fixture.
- Request from Steven any disputed input contract and a reproducible contrary example before assigning an implementation fault.
- Optionally check original full source-owner selftests/CI independently. If unavailable, preserve `NOT_RUN`, not a green checkbox.
- Distinguish tested gate predicate, external collector assumption, action attempt, target effect, customer/business outcome, and claim stage for each conclusion.
- Close on a claim-by-claim record: `SUPPORTED`, `CONTRADICTED`, `NOT_ESTABLISHED`, `OUT_OF_SCOPE`, `NOT_TESTED`—not one overall PASS.

## 11. Institutional pathway: FG-TIDA Terms of Reference and separate specification governance

The published [FG-TIDA Terms of Reference](https://www.itu.int/en/ITU-T/focusgroups/tida/Pages/ToR.aspx) set out relevant *types* of work: **§4.1 use-case/requirements analysis**, **§4.2 architectures including runtime trust control**, **§4.4 machine-readable technical-policy/trust information**, and **§4.5 assessment criteria, metrics and future standardization recommendations**. Its Annex A offers candidate examples, including **A.2.7 runtime trust control plane** and **A.2.8 behavioural trust signals/data models**. The ToR also explicitly excludes general **agentic AI protocols and AI governance** from the Focus Group's own scope; this work must remain framed as relevant **technical trust/identity and runtime decision-boundary evidence**, not generic governance of all AI.

**Do not mistake this future connection for acceptance:** an experimental finding can motivate a *candidate specification or technical report input*. Whether that is suitable for an FG-TIDA deliverable and whether it gains consensus are separate, subsequent review and decision processes. No current report claims authority to approve a technical specification, define a work item unilaterally or assert future transposition into an ITU-T Recommendation.

**The proposed chain:** source contributors and Steven -> Nelson-led bounded UC-4 test decision/experimental report *if admitted* -> separate scientific/cross-contributor specification assessment -> optional draft FG-TIDA technical requirements, guidance, report or proposal subject to the group's ToR/consensus procedures. The evidence must remain reproducible and its negative results available across each handoff.

---

**Audit release statement:** This document makes the limits of our **own** review independently falsifiable. It is designed for third-party reproduction, criticism and correction. It should not be presented as a signed independent laboratory report, product certification or formal standards decision. Steven's original implementation is preserved and credited, and any subsequent author correction must be separately versioned rather than inserted into the frozen record.
