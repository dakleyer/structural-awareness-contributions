#!/usr/bin/env python3
"""Independent bounded countertests of Steven Zhao's pinned S5 decision module.

Review-author harness; NOT authored/endorsed by Steven. No changes to the
vendored source are made. Runs the exact upstream Git blob, not a transcription.

Usage:
  python run_steven_focused_checks.py
  python run_steven_focused_checks.py --source /path/to/examples/S5-Qregister/implementation.py
  python run_steven_focused_checks.py --output evidence/replay.json

A passing *test of a gap* reports an observed limitation, not conformance to S5.
The original author's full selftest and CI suite are different tests and are
not asserted to have run merely because this targeted runner completes.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, asdict
import hashlib
import importlib.util
import json
import pathlib
import platform
import sys
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parent
DEFAULT_SOURCE = ROOT.parent / "upstream" / "implementation.py"
EXPECTED_GIT_BLOB = "4dd9ace3de82ca0ced126656a9f1fa9867bba1f4"
EXPECTED_FIXTURE_BLOB = "3801dfd50a59d9b54650361fcab8fed5ebfcdc6c"
UPSTREAM_PIN = "b59a686b887c2a2545dd22808fb67e629bc95f18"
UPSTREAM_REPO = "https://github.com/zhaoxinghua09-cell/silent-failure-catalog"


def git_blob_hash(content: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()


def load_pinned_implementation(source: pathlib.Path):
    data = source.read_bytes()
    actual_hash = git_blob_hash(data)
    if actual_hash != EXPECTED_GIT_BLOB:
        raise SystemExit(f"SOURCE INTEGRITY FAIL: expected {EXPECTED_GIT_BLOB}, found {actual_hash}; refusing to claim a pinned-source run")
    spec = importlib.util.spec_from_file_location("steven_pinned_implementation", source)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot import verified source")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, actual_hash


@dataclass(frozen=True)
class Scenario:
    id: str
    group: str
    profile: str
    changes: dict
    actual_expected: str
    note: str
    assessment: str


def scenarios():
    # Frozen, intentionally simple reference observation, selected for fixture
    # compatibility.  No original harness branch identifiers are handed to I2.
    return [
        Scenario("PC01", "positive_control", "I2-complete", {}, "EXECUTE",
                 "Valid action remains executable (continuity).", "SUPPORTED_WITHIN_MODEL"),
        Scenario("PC02", "positive_control", "I2-complete", {"supersession_lineage": ["patch-b@gen3"], "current_generation": 3}, "BLOCK_REASSESS",
                 "Disclosed Patch B lineage triggers requalification.", "SUPPORTED_WITHIN_MODEL"),
        Scenario("PC03", "positive_control", "I2-complete", {"freeze_state": "active"}, "DENY",
                 "Explicit active freeze prevents actuation.", "SUPPORTED_WITHIN_MODEL"),
        Scenario("PC04", "positive_control", "I2-complete", {"supersession_lineage": ["patch-b@gen3"], "current_generation": 3, "freeze_state": "active"}, "BLOCK_REASSESS",
                 "Patch B and freeze simultaneously yield both causes in trace.", "SUPPORTED_WITHIN_MODEL"),
        Scenario("PC05", "positive_control", "I2-complete", {"source_available": False, "source_version": "src@absent"}, "HOLD_ESCALATE",
                 "Declared unavailable source is not treated as permission.", "SUPPORTED_WITHIN_MODEL"),
        Scenario("PC06", "positive_control", "I2-complete", {"timestamps": {"observed_at": 1700000000, "t_check": 1700000000, "t_act": 1700000009, "t_freeze": 1700000005}}, "BLOCK_BOUNDARY",
                 "Known in-window freeze-effective timestamp blocks.", "SUPPORTED_WITHIN_MODEL"),
        Scenario("PC07", "positive_control", "I0-ordinary", {"supersession_lineage": ["patch-b@gen3"], "current_generation": 3}, "EXECUTE",
                 "Intentionally ordinary comparator exhibits the modeled failure.", "INTENTIONALLY_WEAK_PROFILE"),
        Scenario("PC08", "positive_control", "I1-defended", {"supersession_lineage": ["patch-b@gen3"], "current_generation": 3}, "EXECUTE",
                 "Intentionally ineffective defended comparator does not replace strong UC21 R1.", "INTENTIONALLY_WEAK_PROFILE"),
        Scenario("CT01", "scope_countertest", "I2-complete", {"authority_state": "REVOKED"}, "EXECUTE",
                 "Q0 still reports PASS and permits when only authority_state is revoked; outside currently implemented semantics.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT02", "scope_countertest", "I2-complete", {"authority_state": "different_principal_not_authorized"}, "EXECUTE",
                 "Q0 does not assess principal/scope values beyond the hardcoded trace.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT03", "scope_countertest", "I2-complete", {"source_version": "src@replaced-untrusted"}, "EXECUTE",
                 "Q3 ignores source_version; no canonical expected-source identity is specified in this example.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT04", "scope_countertest", "I2-complete", {"timestamps": {"observed_at": 1600000000, "t_check": 1700000000, "t_act": 1700000009}}, "EXECUTE",
                 "Q3 ignores extreme age of the observed_at value; no numeric freshness budget is enforced.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT05", "scope_countertest", "I2-complete", {"current_generation": 3, "supersession_lineage": []}, "EXECUTE",
                 "Current generation changes while supplied supersession_lineage is empty; Q4 does not independently compare generations.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT06", "scope_countertest", "I2-complete", {"binding_tokens": []}, "EXECUTE",
                 "Q6 does not consult declared binding_tokens. NOTE: no invalid-token semantics are specified by the fixture.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT07", "scope_countertest", "I2-complete", {"timestamps": {"observed_at": 1700000000, "t_check": 1700000000}}, "EXECUTE",
                 "Q6 treats absent t_act like no interval breach rather than INDETERMINATE; error handling is not modeled.", "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"),
        Scenario("CT08", "scope_countertest", "I2-complete", {"timestamps": {"observed_at": 1700000000, "t_check": 1700000000, "t_act": 1700000009, "t_freeze": 1700000010}}, "EXECUTE",
                 "Future event effective after actuation does not block; legitimate continuity under an irrelevant future event.", "SUPPORTED_WITHIN_MODEL"),
        Scenario("BC01", "epistemic_boundary", "I2-complete", {"timestamps": {"observed_at": 1700000000, "t_check": 1700000000, "t_act": 1700000009}}, "EXECUTE",
                 "No undisclosed t_freeze is visible. Same decision with or without a hidden later event: not a valid test of discovering an unobservable event.", "NOT_A_COUNTEREXAMPLE_TO_AUTHORED_SCOPE"),
        Scenario("BC02", "epistemic_boundary", "I2-complete", {"timestamps": {"observed_at": 1700000000, "t_check": 1700000000, "t_act": 1700000009, "t_freeze": 1700000005}}, "BLOCK_BOUNDARY",
                 "Exact full-frame comparison works, but availability_to_actor_at and acquisition time are absent: no evidence of unannounced-event detection.", "TIME_OF_KNOWLEDGE_NOT_ESTABLISHED"),
    ]


def base_observation():
    return {
        "current_generation": 2,
        "source_version": "src@live",
        "source_available": True,
        "freeze_state": "none",
        "supersession_lineage": [],
        "timestamps": {"observed_at": 1700000000, "t_check": 1700000000, "t_act": 1700000009},
        "authority_state": "current_grant_bounded_to_gen2",
        "binding_tokens": ["t_check", "t_act"],
    }


def neutral_assertion_selftest():
    def expect(actual, registered):
        if actual != registered:
            raise AssertionError(f"adversarial expectation mismatch: actual={actual}, expected={registered}")
    try:
        expect("EXECUTE", "BLOCK_REASSESS")
    except AssertionError:
        return True
    raise AssertionError("test harness incorrectly accepts a planted oracle mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=pathlib.Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=pathlib.Path, default=ROOT.parent / "replay" / "focused_run.json")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    impl, actual_sha = load_pinned_implementation(args.source)
    fixture_bytes = (ROOT.parent / "upstream" / "fixture_spec.json").read_bytes()
    fixture_sha = git_blob_hash(fixture_bytes)
    if fixture_sha != EXPECTED_FIXTURE_BLOB:
        raise SystemExit("SOURCE INTEGRITY FAIL: original fixture_spec.json changed")
    fixture = json.loads(fixture_bytes)
    canonical_map = {"PC01": ("continuity", "EXECUTE"),
                     "PC02": ("supersession", "BLOCK_REASSESS"),
                     "PC03": ("prohibition", "DENY"),
                     "PC04": ("patch-and-freeze", "BLOCK_REASSESS"),
                     "PC05": ("ambiguity", "HOLD_ESCALATE"),
                     "PC06": ("act-window", "BLOCK_BOUNDARY")}
    canonical_dispositions = {"EXECUTE": "EXECUTE", "REASSESS": "BLOCK_REASSESS",
                              "DENY": "DENY", "HOLD_ESCALATE": "HOLD_ESCALATE",
                              "BLOCKED_AT_BOUNDARY": "BLOCK_BOUNDARY"}
    for rid, (branch, correct_expected) in canonical_map.items():
        registered = fixture["branches"][branch]["correct_outcome"]
        if canonical_dispositions[registered] != correct_expected:
            raise SystemExit("CANONICAL FIXTURE AGREEMENT FAIL: " + rid)
    neutral_assertion_selftest()
    rows = []
    for sc in scenarios():
        data = base_observation()
        data.update(sc.changes)
        obs = impl.Observation(**data)
        status, verdict = impl.run(sc.profile, obs)
        observed = verdict.guard_decision
        expected_exit = impl.exit_code_for(observed)
        oracle_match = observed == sc.actual_expected
        own_consistency = status == expected_exit and (
            (verdict.attempted_action == impl.ACTION_APPLY) == (observed == impl.GUARD_EXECUTE)
        )
        both_reasons = "BOTH REASONS PRESENT" in " | ".join(str(x) for x in verdict.lines)
        if sc.id == "PC04":
            own_consistency = own_consistency and both_reasons
        rows.append({
            "id": sc.id, "type": sc.group, "profile": sc.profile,
            "changed_inputs": sc.changes, "full_observation": obs.as_record(),
            "registered_expected_verdict": sc.actual_expected,
            "observed_guard": observed, "observed_attempt": verdict.attempted_action,
            "observed_exit": status, "reported_gates": verdict.lines,
            "note": sc.note, "interpretation": sc.assessment,
            "oracle_matches": oracle_match, "internal_record_consistent": own_consistency,
            "observed_as_registered": oracle_match and own_consistency,
        })
        if not args.quiet:
            flag = "OBSERVED" if oracle_match and own_consistency else "MISMATCH"
            print(f"{sc.id:4s} {sc.group:19s} {observed:18s} {verdict.attempted_action:6s} {flag} | {sc.assessment}")
    # Differential controls: each adversarial case changes one declared input
    # dimension (or, for CT05, exposes a missing-lineage consistency assumption).
    # Repeated verdict AND full gate trace establish exactly which input was ignored.
    by_id = {row["id"]: row for row in rows}
    differential_pairs = [("PC01", i) for i in
                          ("CT01", "CT02", "CT03", "CT04", "CT05", "CT06", "CT07", "BC01")]
    differential_pairs.extend([("PC06", "BC02"), ("PC01", "PC06")])
    diffs = []
    for a, b in differential_pairs:
        left, right = by_id[a], by_id[b]
        diffs.append({"left": a, "right": b,
                      "same_verdict": left["observed_guard"] == right["observed_guard"],
                      "same_action": left["observed_attempt"] == right["observed_attempt"],
                      "same_gate_trace": left["reported_gates"] == right["reported_gates"]})
    assert all(x["same_verdict"] and x["same_action"] and x["same_gate_trace"]
               for x in diffs[:-1]), "adversarial invariance check no longer holds"
    assert not diffs[-1]["same_verdict"], "Q6 control failed to distinguish a supplied freeze event"
    derived = {
        "purpose": "Independent focus: Steven Zhao S5 Q0/Q3/Q4/Q6 and positive controls",
        "upstream": UPSTREAM_REPO,
        "upstream_commit": UPSTREAM_PIN,
        "upstream_file": "examples/S5-Qregister/implementation.py",
        "verified_upstream_git_blob_sha1": actual_sha,
        "verified_upstream_fixture_git_blob_sha1": fixture_sha,
        "source_sha256": hashlib.sha256(args.source.read_bytes()).hexdigest(),
        "runner_python": platform.python_version(), "runner_platform": platform.platform(),
        "sample_size": len(rows), "groups": dict(Counter(r["type"] for r in rows)),
        "interpretations": dict(Counter(r["interpretation"] for r in rows)),
        "all_observed_as_registered": all(x["observed_as_registered"] for x in rows),
        "caution": "Oracle match is not a successful S5 implementation assessment. The countertests deliberately show missing predicate enforcement outside the six published branches. This is not a run of Steven's entire original harness/CI, and no AWS/RDS target was exercised.",
        "independent_assertion_negative_control": "INTENTIONALLY_FALSE_EXPECTATION_REJECTED",
        "paired_differential_controls": diffs,
        "results": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(derived, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if not args.quiet:
        print("\nRecorded %d cases; candidate scope gaps: %d; oracle/trace mismatches: %d" % (
            len(rows), len([x for x in rows if x["interpretation"] == "GAP_CONFIRMED_IN_SELECTED_GATE_COVERAGE"]),
            len([x for x in rows if not x["observed_as_registered"]])))
        print("Reproduction record:", args.output)
    return 0 if derived["all_observed_as_registered"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
