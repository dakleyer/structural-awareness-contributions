#!/usr/bin/env python3
"""Independent reviewer-controlled characterization of a frozen original S5 module.

The output is a finite, deterministic *invariance census*, NOT an empirical
proof of S5 conformance or discovery of hidden source dependencies. The whole
upstream implementation is loaded unchanged after its Git blob SHA is checked.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
from hashlib import sha1, sha256
from importlib.util import module_from_spec, spec_from_file_location
import itertools
import json
from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "upstream" / "implementation.py"
FIXTURE = ROOT / "upstream" / "fixture_spec.json"
GIT_SOURCE = "4dd9ace3de82ca0ced126656a9f1fa9867bba1f4"
GIT_FIXTURE = "3801dfd50a59d9b54650361fcab8fed5ebfcdc6c"
UPSTREAM_PIN = "b59a686b887c2a2545dd22808fb67e629bc95f18"


def blob_sha(content: bytes) -> str:
    return sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()


def checked_source(path=SOURCE):
    raw = path.read_bytes()
    if blob_sha(raw) != GIT_SOURCE:
        raise ValueError("PIN_MISMATCH: refusing execution of modified upstream source")
    return raw


def checked_fixture(path=FIXTURE):
    raw = path.read_bytes()
    if blob_sha(raw) != GIT_FIXTURE:
        raise ValueError("PIN_MISMATCH: refusing execution of modified upstream fixture")
    return json.loads(raw)


def import_upstream():
    checked_source()
    checked_fixture()
    spec = spec_from_file_location("steven_s5_pin", SOURCE)
    assert spec is not None and spec.loader is not None
    m = module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def static_attrs(source_text: str):
    tree = ast.parse(source_text)
    funcs = {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    direct = {}
    for fn in ["_trace_gates_i0","_trace_gates_i1","_trace_gates_i2","_freeze_lands_inside_act_window"]:
        n=funcs[fn]
        attrs=Counter(x.attr for x in ast.walk(n) if isinstance(x, ast.Attribute)
                      and isinstance(x.value,ast.Name) and x.value.id=="obs"
                      and isinstance(x.ctx,ast.Load))
        direct[fn]=dict(sorted(attrs.items()))
    return direct


def frames():
    t=1700000000
    base={"observed_at":t,"t_check":t,"t_act":t+9}
    return {
        "base":base,
        "source_stale":dict(base,observed_at=1600000000),
        "freeze_before":dict(base,t_freeze=t-5),
        "freeze_at_check":dict(base,t_freeze=t),
        "freeze_inside":dict(base,t_freeze=t+5),
        "freeze_at_act":dict(base,t_freeze=t+9),
        "freeze_after":dict(base,t_freeze=t+10),
        "missing_t_act":{"observed_at":t,"t_check":t},
        "missing_t_check":{"observed_at":t,"t_act":t+9},
        "nonmonotonic":{"observed_at":t,"t_check":t,"t_act":t-1},
    }


def observation_dict(**kw):
    d={"current_generation":2,"source_version":"src@live", "source_available":True,
       "freeze_state":"none","supersession_lineage":(),"timestamps":frames()["base"],
       "authority_state":"current_grant_bounded_to_gen2", "binding_tokens":("t_check","t_act")}
    d.update(kw)
    return d


def decision(mod, obs_dict):
    obs=mod.Observation(**obs_dict)
    exit_status,v=mod.run("I2-complete",obs)
    return (exit_status,v.guard_decision,v.attempted_action,
            tuple(tuple(row) for row in v.lines))


def snapshot_label(sig):
    return {"0":"EXECUTE"}.get(str(sig[0]),sig[1])


def scenario_tests(mod):
    """Separately specified reviewer cases, with preserved boundary warnings."""
    base=observation_dict()
    alternatives={
      "authority_revoked":({"authority_state":"REVOKED"},"Q0","within broader S5; outside author's declared fixture"),
      "wrong_principal":({"authority_state":"different_principal_not_authorized"},"Q0","within broader S5; outside author's declared fixture"),
      "wrong_source":({"source_version":"src@not-authoritative"},"Q3","no declared authoritative source identifier for synthetic example"),
      "stale_observation":({"timestamps":frames()["source_stale"]},"Q3","no declared numerical max-age; deep Q3 excluded by owner"),
      "generation_without_lineage":({"current_generation":3},"Q4","may violate stipulated lineage contract; requires independent input-source adjudication"),
      "binding_tokens_empty":({"binding_tokens":()},"Q6","binding-token validity not defined in original fixture"),
      "missing_action_timestamp":({"timestamps":frames()["missing_t_act"]},"Q6","incomplete observation outside six published cases"),
      "nonmonotonic_action_time":({"timestamps":frames()["nonmonotonic"]},"Q6","ill-formed timeline outside published fixture"),
      "irrelevant_later_freeze":({"timestamps":frames()["freeze_after"]},"Q6","positive nonblocking control"),
      "freeze_inside":({"timestamps":frames()["freeze_inside"]},"Q6","positive blocking control"),
      "freeze_at_check":({"timestamps":frames()["freeze_at_check"]},"Q6","boundary-inclusive blocking"),
      "freeze_at_act":({"timestamps":frames()["freeze_at_act"]},"Q6","boundary-inclusive blocking"),
      "source_absent":({"source_available":False},"Q3/Q5","known unavailable source; negative control"),
      "patch_b_lineage":({"supersession_lineage":("patch-b@gen3",),"current_generation":3},"Q4","known supersession; negative control"),
      "active_freeze":({"freeze_state":"active"},"Q5","known freeze; negative control"),
    }
    ref=decision(mod,base)
    results=[]
    for name,(changes,gate,remark) in alternatives.items():
        sig=decision(mod,observation_dict(**changes))
        results.append({"case":name,"S5_gate":gate,"changed":changes,
              "observed_guard":sig[1],"attempt":sig[2],"exit_code":sig[0],
              "same_as_clean_trace":sig==ref,
              "scope_caveat":remark})
    return {"baseline":{"guard":ref[1],"attempt":ref[2],"exit":ref[0]},"variations":results}


def controls_fail_loudly(mod, native_fixture):
    """Negative controls on OUR own adjudication instrument, not Steven's."""
    good=decision(mod, observation_dict())
    controls={}
    try:
        assert good[1] == "DENY", "deliberately incorrect expectation"
    except AssertionError:
        controls["deliberate_false_oracle"]="REJECTED_AS_REQUIRED"
    else:
        controls["deliberate_false_oracle"]="FAILED_TO_REJECT"
    bad=SOURCE.read_bytes()+b"\n# deliberate audit tamper\n"
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"implementation.py"; p.write_bytes(bad)
        try: checked_source(p)
        except ValueError: controls["source_byte_tamper"]="REJECTED_AS_REQUIRED"
        else: controls["source_byte_tamper"]="FAILED_TO_REJECT"
        p2=Path(d)/"fixture.json"
        p2.write_bytes(FIXTURE.read_bytes()+b" ")
        try: checked_fixture(p2)
        except ValueError: controls["fixture_byte_tamper"]="REJECTED_AS_REQUIRED"
        else: controls["fixture_byte_tamper"]="FAILED_TO_REJECT"
    required={"continuity":"EXECUTE","supersession":"BLOCK_REASSESS",
         "prohibition":"DENY","patch-and-freeze":"BLOCK_REASSESS",
         "act-window":"BLOCK_BOUNDARY","ambiguity":"HOLD_ESCALATE"}
    baseline_instrument_detects_always_execute=sum(v!="EXECUTE" for v in required.values())
    controls["always_execute_diagnostic"]={"wrong_branches":baseline_instrument_detects_always_execute,
       "status":"KILLED_AS_REQUIRED" if baseline_instrument_detects_always_execute else "NOT_KILLED"}
    controls["deny_all_diagnostic"]={"positive_continuity_failed":required["continuity"]!="DENY",
       "status":"KILLED_AS_REQUIRED" if required["continuity"]!="DENY" else "NOT_KILLED"}
    # Native author six: our author-original source + source-owned fixture, status
    # names normalized rather than silently treated as exact string equality.
    aliases={"EXECUTE":"EXECUTE","REASSESS":"BLOCK_REASSESS","DENY":"DENY",
             "BLOCKED_AT_BOUNDARY":"BLOCK_BOUNDARY","HOLD_ESCALATE":"HOLD_ESCALATE"}
    for key in required:
        spec=aliases[native_fixture["branches"][key]["correct_outcome"]]
        assert spec==required[key],(key,spec,required[key])
    controls["original_fixture_disposition_check"]="SIX_OF_SIX_MATCHING_REGISTERED_EXPECTATIONS"
    assert all(v=="REJECTED_AS_REQUIRED" for k,v in controls.items() if k in
               {"deliberate_false_oracle","source_byte_tamper","fixture_byte_tamper"})
    return controls


def exhaustive(mod, output_csv):
    """6,480 synthetic combinations; not all are physically admissible worlds."""
    factors={
      "authority_state":["current_grant_bounded_to_gen2","REVOKED","wrong_scope"],
      "current_generation":[2,3,4],
      "source_version":["src@live","src@stale","src@unknown"],
      "binding_tokens":[("t_check","t_act"),(),("bad",)],
      "source_available":[True,False],
      "supersession_lineage":[(),("patch-b@gen3",)],
      "freeze_state":["none","active"],
      "frame":list(frames().keys()),
    }
    total=1
    for vs in factors.values():total*=len(vs)
    assert total==6480,total
    fields=list(factors)
    distribution=Counter()
    routing=defaultdict(set)
    conformance=Counter()
    a_by_route=defaultdict(set)
    with output_csv.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=["case_index",*fields,"exit","guard","attempt","trace_sha256","model_guard_consistency"])
        w.writeheader()
        for idx,values in enumerate(itertools.product(*(factors[k] for k in fields)),1):
            row=dict(zip(fields,values))
            fcase=row.pop("frame");row["timestamps"]=frames()[fcase]
            sig=decision(mod,observation_dict(**row))
            digest=sha256(repr(sig[3]).encode()).hexdigest()
            assert sig[0] == (0 if sig[1]=="EXECUTE" else 2)
            assert (sig[2]=="APPLY")==(sig[1]=="EXECUTE")
            stable=(row["source_available"],bool(row["supersession_lineage"]),row["freeze_state"],fcase)
            routing[stable].add((sig[1],sig[2],digest))
            a_by_route[stable].add((row["authority_state"],row["current_generation"],row["source_version"],tuple(row["binding_tokens"])))
            distribution[sig[1]]+=1
            # *Do not* label cross-products as valid S5 worlds; many contain
            # mismatched generation/authority/lineage or clocks.
            w.writerow({"case_index":idx,"authority_state":row["authority_state"],
                "current_generation":row["current_generation"],
                "source_version":row["source_version"],
                "binding_tokens": ",".join(row["binding_tokens"]),
                "source_available":row["source_available"],
                "supersession_lineage":", ".join(row["supersession_lineage"]),
                "freeze_state":row["freeze_state"],"frame":fcase,
                "exit":sig[0],"guard":sig[1],"attempt":sig[2],
                "trace_sha256":digest,"model_guard_consistency":True})
    changing=[(route,outs) for route,outs in routing.items() if len(outs)>1]
    assert not changing,changing[:2]
    return {"synthetic_combinations":total,"routing_signatures":len(routing),
      "metadata_variants_per_routing_signature":81,
      "guard_distribution":dict(sorted(distribution.items())),
      "metadata_sensitive_routes":len(changing),
      "metadata_invariance_holds_for_all_routing_signatures":True,
      "interpretation":"A synthetic sensitivity census: invariant verdict/trace under changes to four named input fields if source_available, lineage, freeze state, and timestamp frame remain fixed; many cross-products are inconsistent or outside the six published fixtures and are not independent valid-world conformance tests.",
      "all_output_traces_in_csv":True}


def run(output_dir):
    output_dir.mkdir(parents=True,exist_ok=True)
    source=checked_source()
    native=checked_fixture()
    mod=import_upstream()
    attrs=static_attrs(source.decode("utf-8"))
    probes=scenario_tests(mod)
    ctrl=controls_fail_loudly(mod,native)
    census=exhaustive(mod,output_dir/"synthetic_full_factor_grid.csv")
    audit={"status":"SECOND_PASS_REVIEWER_CONTROLLED_REPLAY_NOT_AN_INDEPENDENT_SIGNED_AUDIT",
     "date":"2026-10-11", "source_commit":UPSTREAM_PIN, "git_blob_source":GIT_SOURCE,
     "git_blob_fixture":GIT_FIXTURE,"source_sha256":sha256(source).hexdigest(),
     "static_obs_reads":attrs,"targeted_probes":probes,"negative_controls":ctrl,
     "factor_grid":census,"claim_ceiling":"Dynamically evaluated decision predicates in original standalone S5 module; not author-harness reproduction, independent target effect, full seven-gate conformance, strong R1/R2, or AWS product test."}
    j=output_dir/"audit_result.json"
    j.write_text(json.dumps(audit,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    assert census["metadata_invariance_holds_for_all_routing_signatures"]
    assert len(probes["variations"])==15
    assert all(v["same_as_clean_trace"] for v in probes["variations"] if v["case"] in
         {"authority_revoked","wrong_principal","wrong_source","stale_observation",
          "generation_without_lineage","binding_tokens_empty","missing_action_timestamp",
          "nonmonotonic_action_time"})
    assert any(v["observed_guard"]=="BLOCK_BOUNDARY" for v in probes["variations"])
    return audit


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",type=Path,default=ROOT/"replay")
    args=p.parse_args()
    x=run(args.out)
    print("PIN:",x["git_blob_source"])
    print("FOCUSED VARIATIONS:",len(x["targeted_probes"]["variations"]))
    print("SYNTHETIC GRID:",x["factor_grid"]["synthetic_combinations"],x["factor_grid"]["guard_distribution"])
    print("METADATA INVARIANCE:",x["factor_grid"]["metadata_invariance_holds_for_all_routing_signatures"])
    print("SELF-TEST NEGATIVE CONTROLS:",x["negative_controls"])
    print("Result:",args.out/"audit_result.json")
if __name__=="__main__":
    main()
