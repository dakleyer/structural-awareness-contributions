# PART 2 — UC-4 experimental review, contributor roles, and stopping rule

**Date:** 11 October 2026  
**Status:** Working governance and experimental-process proposal; **not yet accepted by Nelson, Steven, FG-TIDA, or an independent auditor**.  
**Purpose:** decide whether the technical contribution already achieved by Steven Zhao should be closed at its declared diagnostic scope or tested further under a bounded UC-4 process. Keep scientific interpretation and later specification work institutionally separate.

## Executive decision

A complete, independently replayable technical **review package** exists for selected aspects of Steven's `S5-Qregister` decision module (Part 1). An independent **audit opinion** does **not** yet exist. The package contains 18 replay cases (including seven adversarial cases establishing selected Q0/Q3/Q4/Q6 coverage limits), exact upstream source identity, a separate test runner, raw traces, positive controls, and an integrity check. It does **not** run Steven's full original CI, assert native AWS behavior, or decide whether his authored examples should be expanded.

The next decision is **not** “shall we build EA into S5?” It is “what factual claim has already been answered, and is there one further question whose discriminating value justifies a small, independently reviewable campaign?”

Our recommendation is to invite Nelson to act as **UC-4 experimental lead, scope/readiness reviewer, and stopping-point recommender**, consistent with his own public offer. If he also authors or coordinates the runs, do **not** label him a wholly independent third-party auditor of that same work. A different reviewer should reproduce or adjudicate contested results where independent assurance is desired.

## 1. Source-grounded requests from Nelson — distinguished from our proposed process

| Public statement | Requested element | Status |
|---|---|---|
| [UC-4 experimental cycle](https://github.com/FG-TIDA/use-cases/issues/4#issuecomment-5846988611) | Nelson proposes to lead question selection, controlled tests, counter-tests, analysis and report; agree resources and stopping point per campaign; preserve source ownership | **Proposed by Nelson**, not a universal mandate |
| [UC-4 public schema 1.1.0-r1](https://github.com/FG-TIDA/use-cases/issues/4#issuecomment-5871266911) | Versioned input, explicit assessment time and determination reference, source provenance, required capabilities, distinct technical/preparer/contributor review states | **Published as candidate schema**; validation ≠ semantic approval ≠ execution |
| [UC-21 stateful S5 route](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-5900761904) | One strongly defended baseline and legitimate-continuity control, guard/attempt/target readback, single-writer/lease/check-to-act assumptions, bypass separate; D1 only after corrected baseline | **Proposed first executable route**; capability estimate still required |
| [UC-21 first S5 branch](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-5936720586) | One Patch-B supersession branch plus valid continuity; G1/G4 sensitivity separately; pinned source/cases and expected observations; equal resources for conventional comparator | **Candidate scope**, no experiment admitted |
| [UC-4 Steven adapter request](https://github.com/FG-TIDA/use-cases/issues/4#issuecomment-6088846416) | **One** catalogue entry, unambiguous pin (v0.1.2 issue), planted fault, expected observation and positive control for schema 1.1.0 review | **Separate adapter review**, explicitly *not* campaign admission |
| [UC-21 most recent lead offer](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-6089067288) | Nelson offers to lead coordination, test contract, frozen inputs, runs, counter-tests, comparative report, and agree a UC-4 review/execution window | **Explicitly offered for a UC-4-linked candidate primarily discussed there as Matías's CDA**; do not silently transfer that commitment to the entire Steven S5 effort |

The UC-4 cross-organisational defence use case, the UC-4 *testbed/experimental-cycle proposal*, Steven's catalogue-entry **adapter**, Steven's runnable **S5-Qregister/T08-S5Q2 examples**, Matías's separate **CDA candidate**, and DDS stages **A/B/C** are different objects. An adapter accepted for review is not a stateful experiment, and UC-4 Stage 0/1 does not imply DDS Stage B/C validation.

## 2. Responsibilities (proposed, subject to acceptance)

| Role | Responsibilities | Explicit limit |
|---|---|---|
| **Iván — UC-21 challenge custodian / scientific source contributor** | Provide frozen S5/T08 source references; articulate the original `F_I` outcome, the legitimate-activity comparator, candidate hypotheses and non-negotiable fairness assumptions; supply Part 1 adverse and positive evidence; review test-contract fidelity | Does **not** revise the frozen oracle after seeing candidate output, require EA architecture, or declare a standards result |
| **Steven — S5 implementation/catalogue source owner** | Confirm provenance and declared scope; inspect and reproduce Part 1 objections; distinguish stipulated inputs from actually enforced Q0–Q6 predicates; optionally submit one pinned catalogue adapter or agreed S5 successor with own tests/positive controls | Not expected to retrofit production AWS, full S5 or R2 merely to defend the existing illustrative model; no unconsented source changes |
| **Nelson — UC-4 experimental lead / readiness and stop assessor** | Evaluate whether an executable capability exists, whether the selected question is discriminating, fairness/neutrality, admissible schema and cost; work with owners to freeze protocol; coordinate execution, counter-tests, interpretation and experimental report; recommend stop/continue/defer | A leadership offer, **not** automatic acceptance of all S5/CDA campaigns or an independent audit credential; does not adopt or certify scientific specifications |
| **Matías — separate CDA candidate source owner, if selected** | Supply a pinned implementation, verifier profile, signed vectors, native two-axis semantics and effect observations; review adapter fidelity | CDA is not Steven's simulator, and CDA Stage-0 readiness does not automatically establish S5 or DDS Stage C |
| **Independent evidence reviewer** | Validate source pins, negative controls, source/oracle separation, raw commands and outputs, claim-to-test mapping and disputed interpretations; independently reproduce selected cases; sign/caveat disposition | Appoint separately if independent audit/assurance is claimed; should not be sole author of the same evaluated test oracle |
| **Later specification reviewers / other participants** | After campaign closes, assess whether any newly discovered, necessary and falsifiable requirement belongs in a DDS Stage A successor; review architecture/implementation in later stages if funded | No automatic EA inclusion, standardisation, FG-TIDA endorsement or universal theorem |

## 3. A stage-gated, finite workflow

### Gate 0 — Technical contribution recognition and scope confirmation

- Freeze Steven's S5 implementation at `b59a686b887c2a2545dd22808fb67e629bc95f18`; record canonical release/tag context separately.
- Give Steven the independent **reviewable** Part 1 packet and explicitly invite methodological objections and reproducible contrary examples.
- Log distinctions: `CONFIRMED_BY_REPLAY`, `SUPPORTED_BY_SOURCE_ONLY`, `AUTHOR_REPORTED`, `OUT_OF_SCOPE`, `NOT_ESTABLISHED`.
- **Possible conclusion:** declare the *bounded synthetic diagnostic contribution* complete, with its limits. This requires **no further UC-4 campaign**.

### Gate 1 — UC-4 feasibility and admission recommendation (Nelson-led)

Nelson is invited to choose among:

1. `CLOSE_AT_DECLARED_MODEL_SCOPE` — the useful question is already answered at the evidence level claimed;
2. `PROPOSE_ONE_BOUNDED_EXPERIMENT` — name the precise unanswered, discriminating question and its executable contract;
3. `DEFER_OR_REJECT_ADMISSION` — required capability, expected observations, independent effect readback, consent, or resource window not available.

This is **not** an ask to run all S5 gates or all six UC-21 scenarios. Review one pinned catalogue entry **separately** if Nelson wishes to calibrate the adapter first.

### Gate 2 — Frozen experiment contract (only on explicit agreement)

Minimal initial S5 pair:

- **Case P:** unchanged justified patch must `EXECUTE`, `APPLY`, and produce the expected readback within the latency/resource envelope.
- **Case S:** Patch B materially supersedes the queued patch; a corrected candidate must prevent stale target mutation, with explicit `guard -> attempt -> target` trace and legitimate continuity preserved.

Preregister: exact owners and repository pins; challenge and independent expected outcomes; input-availability times; source provenance/freshness and omitted-source assumptions; single-writer/lease/bypass conditions; conventional **strong** peer (not Steven's deliberately weak local `I1-defended`); capabilities, evaluator/candidate source equality, cost/human/latency envelope; negative fault-control G1/G4 semantics and nontrivial positive controls; hypothesis and stop rule. An adapter may describe these facts but **cannot substitute for target-effect execution**.

### Gate 3 — Execution, counter-tests and written disposition

Nelson coordinates and publishes, subject to agreed resources and permissions:

- Frozen command, environment, test version, input hashes, raw exit/status logs, guard/attempt/target readback and execution timestamp.
- Controls passed/failed/inconclusive/not run **per claim**, including legitimate activity (avoid deny-all).
- Distinguish `SOURCE_SEMANTICS`, `TEST_INSTRUMENT`, `SIMULATED_MODEL_EFFECT`, and `NATIVE_PRODUCT_EFFECT`.
- Give Steven and Iván a response window to flag input and expectation errors; preserve original findings and corrections as explicit successors.
- Separate **review of a result** from **authorship and execution of the test**. If formal independent scientific assurance is needed, commission a disinterested rerun/adjudication.

### Gate 4 — Nelson's stopping recommendation and joint record

Nelson should propose the **closure disposition** and the group should record either:

- `CLOSED_WITH_BOUNDED_FINDINGS`: the predeclared question is answered sufficiently at the declared evidence level, even if a conventional defence succeeds, or if no new EA requirement is justified;
- `INCONCLUSIVE_OR_NOT_EVALUABLE`: necessary capability/observation missing or conflicting — **not** a pass, failure or mandate for endless tests;
- `ONE_SUCCESSOR_EXPERIMENT_APPROVED`: exactly one new question, a separate pin and a new pre-agreed budget/stop rule, where the first result materially motivates it.

A failed corrected-baseline attempt is **not** eligible to count as an R2 recurrence. If a dynamic conventional implementation succeeds on D1 under matched constraints, give it full credit; escalation is not mandatory. Never extend simply to find a weakness.

### Gate 5 — Scientific interpretation and specification pathway (subsequent and separately staffed)

After the bounded report closes, the UC-21/DDS research side—not UC-4 experimental leadership acting alone—may review whether results support *new candidate specifications*, need modification of earlier proposed requirements, or show that established controls suffice. Keep published raw experimental results immutable and cite them from successor requirements. Use a new, explicit DDS Stage A specification-discovery/adjudication exercise, ideally with contributors beyond the original source/test authors. DDS Stage B and Stage C require their **own** review objects and evidence. Neither UC-4 nor this report approves a standard.

## 4. Requested decisions from collaborators

**Steven:** Does the declared local S5 scope already satisfactorily conclude the runnable diagnostic contribution? Which Q0–Q6 statuses are stipulations rather than enforced checks? Would you like to inspect the complete independent Part 1 packet and respond to the seven focused negative variations? Would you submit one pinned SF catalogue entry for **separate** UC-4 adapter review?

**Nelson:** Would you agree to act as UC-4 *experimental lead / scope assessor / stopping-point recommender* for **one selected bounded investigation**, subject to explicit capability and resources review? If not, do you recommend closing this at the diagnostic-model level now? If yes, which source-owned candidate should be selected first—S5, the separately prepared CDA candidate, or one catalogue adapter only—and what would count as sufficient evidence to stop?

**Iván:** Provide the original challenge and the Part 1 technical packet; accept an independently justified conventional success or a null result; defer all proposed specification changes until post-experiment source separation and review.

## 5. Documents and provenance

- **Part 1:** `Steven_S5_Part1_Reproducible_Review_2026-10-11.zip` and `Steven_S5_Part1_Technical_Findings_2026-10-11.md` (self-contained bounded focused rerun, not signed external audit).
- **This Part 2:** proposed decision and governance process, not an execution result.
- **Part 3 (future):** outcome-based DDS specification assessment by an appropriately distinct review team. It must not be drafted as established findings before Gate 4 closes.
- [UC-21 original frozen case](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/USE_CASE.md).
- [Steven S5 pinned companion](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/tree/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister).
- [Nelson UC-4 discussion](https://github.com/FG-TIDA/use-cases/issues/4).
- [UC-21 discussion](https://github.com/FG-TIDA/use-cases/issues/21).

**Proposed decision boundary:** A scientific contributor may request scrutiny; the implementation owner may qualify or correct; Nelson may coordinate and recommend when an agreed experimental scope is enough; an independent reviewer may challenge the evidence; **later specification authors** decide what, if anything, to propose as a requirement. These are not interchangeable authorities.
