# PART 1 — Steven Zhao's S5 contribution: focused technical findings, adversarial countertests, and claim boundaries

**Date:** 11 October 2026  
**Document status:** EXECUTED FOCUSED REVIEW — bounded, reviewer-controlled; **not** a complete independent scientific audit, a native AWS test, or an FG-TIDA decision.  
**Scope:** Steven Zhao (Xinghua Zhao, `@zhaoxinghua09-cell`) `silent-failure-catalog` examples `S5-Qregister` and `T08-S5Q2`; detailed executable stress testing here is limited to the **exact pinned `S5-Qregister/implementation.py`** and its selected Q0/Q3/Q4/Q6 decision claims. No changes have been made to Steven's repository.  
**What is deliberately NOT in this Part 1:** a complete comparison with our 00I-STATEFUL evidence, the DDS-wide research synthesis, Nelson's UC-4 campaign decision, or a proposed public reply. Those are separate subsequent parts.

## 1. Disposition in one page

The executable S5 companion is **a real and useful model-level technical contribution**. Steven's review iterations substantially improved it: case-identity blinding at the interface, independent Patch B/freeze fixture factors, negative controls, repaired crosswalk integrity, unconditional modeled Q6 check, separate observation of a modeled target, and distinct behavioral/input/source-code mutation categories. The positive-continuity and no-source controls matter; this is not merely an always-deny implementation.

**The limits are more precise than “it needs more tests.”** We ran a deliberately bounded independent set of **18 deterministic observations** against Steven's **byte-for-byte original implementation**, with a valid Git blob SHA checked before import. The six positive `I2-complete` cases agree with the published branch expectations. Two additional weak-comparator checks behave as designed. **Seven adversarial variations outside the six published branches returned `EXECUTE/APPLY` unchanged** despite manipulating current authority, source identity/freshness, the current generation without corresponding lineage, a binding-token field, or the completeness of timing data. In all seven the reported gate trace was identical to the clean continuity control. A separate positive test preserved execution when a freeze would become effective *after* the modeled actuation.

This is **direct evidence of selected predicate/contract non-enforcement in the bounded S5 evaluator**, not proof that Steven's stated six-branch fixture is broken, nor proof that a real AWS/RDS system would act unsafely. His own fixture explicitly stipulates source completeness and excludes deep Q3 freshness semantics. The fair scientific finding is that **passing the existing examples cannot be promoted to full substantive conformity with each of S5's seven Q0–Q6 requirements.**

**Claim ceiling:** supported as a falsifiable, executable diagnostic model and verifier-side test aid **within its stipulated inputs and deterministic effect model**; **not established** as complete Q0–Q6 validation, independent reference/oracle completeness, detection of unannounced future events, target-effect fidelity, a corrected strong R1 comparator, R2 recurrence, or native AWS implementation behavior.

A full reconstruction of Steven's original CI and full `harness.py --selftest` was **not** run by this Part 1; our independent runner executed the verified `implementation.py` directly. The author-reported original CI results and his own test results retain their provenance and are not rebranded as this review's evidence.

## 2. Source identity, chain of custody, and method

| Item | Frozen source / observation |
|---|---|
| Source owner | Xinghua Zhao / Steven Zhao, `zhaoxinghua09-cell` |
| Repository | `https://github.com/zhaoxinghua09-cell/silent-failure-catalog` |
| Reviewed commit | `b59a686b887c2a2545dd22808fb67e629bc95f18` |
| Exact executable source | [`examples/S5-Qregister/implementation.py`](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister/implementation.py) |
| **Git blob hash — code** | **`4dd9ace3de82ca0ced126656a9f1fa9867bba1f4`** — local copy independently matched by `git hash-object` and by the runner's Git-blob hash gate |
| Native `fixture_spec.json` blob | `3801dfd50a59d9b54650361fcab8fed5ebfcdc6c` — pinned file independently matched, used to check positive expected-disposition mappings |
| Native `harness.py` blob (inspected, **not locally executed**) | `3e4aa94b3278bbd0a23297b2a225a5d3bd2877c9` |
| Separate T08-S5Q2 runner blob (inspected, **not locally executed**) | `2dfa54f737e61c2892442e775a3fd6251ef05600` |
| Upstream License | MIT for `examples/` and fixture/example docs at the reviewed pin (the catalog's separate `failures/` prose remains under its own content terms); license Git blob `c16595aceab22ed8ed79aa638b09e7a64d48eebe` |
| Underlying Challenge | [UC-21 Annex S5](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/annexes/scenarios/S5.md) — S5 Q0–Q6 |
| Technology correspondence | [UC-21 Annex T08 — Step Functions / RDS](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/annexes/technology/T08.md), **design only**; distinct from Zhao's `examples/T08-S5Q2` |
| Review environment | Python 3.13.5; Linux x86_64. Stdlib only; no AWS, database, external simulator, network, or human tester |

**Execution procedure.** The independent `run_steven_focused_checks.py` imports the exact source bytes, refuses any source whose Git blob differs from the pinned value, constructs ordinary `Observation` objects, calls Steven's public `run(profile, obs)` and records exit status, guard decision, attempted action, gate lines and the full input. It does **not** patch `implementation.py`, pass branch names to it, or use Steven's expected-output generator as the judge of the newly invented negative cases. Positive-control expected dispositions are checked against his frozen `fixture_spec.json`; expected outputs for adversarial extensions are expressly reviewer-registered predictions.

The test harness has two self-controls: (1) a deliberately wrong expected verdict must trigger assertion failure; (2) a one-byte change to source in a disposable copy must be rejected by the Git blob integrity gate **before import**. The full JSON record was generated twice with byte-identical SHA-256, proving deterministic reproduction **in this environment**. These controls do not establish independence of the original author's oracle or a separate human reviewer.

**Important nomenclature:** `I0-ordinary`, `I1-defended`, `I2-complete` are Steven's local examples. They are **not** UC-21's R0/R1/R2, and `I2-complete` is not the frozen, strong AWS-I2 tested under a new source-set regime. Original `R1` needs a strong defense that demonstrably corrects the original case before a true `R2` is possible.

## 3. Reproduced reference controls — what definitely works in the local model

| ID | Author's native branch / profile | Registered expected | Observed guard | Attempted action | Finding |
|---|---|---|---|---|---|
| PC01 | I2 clean continuity | EXECUTE | **EXECUTE** | APPLY | Legitimate action not indiscriminately blocked |
| PC02 | I2 Patch B supersession | REASSESS | **BLOCK_REASSESS** | NONE | Explicit lineage triggers block/requalification |
| PC03 | I2 freeze only | DENY | **DENY** | NONE | Explicit prohibition enforced |
| PC04 | I2 Patch B + freeze | REASSESS | **BLOCK_REASSESS** | NONE | Both reasons preserved in trace |
| PC05 | I2 source unavailable | HOLD/ESCALATE | **HOLD_ESCALATE** | NONE | Explicitly unavailable source is not permission |
| PC06 | I2 freeze effective between check and act | BLOCKED_AT_BOUNDARY | **BLOCK_BOUNDARY** | NONE | Timestamp interval check works when the event timestamp is supplied |
| PC07 | I0 ordinary, Patch B disclosed | Intentional exposure | **EXECUTE** | APPLY | Weak/ordinary profile intentionally permits |
| PC08 | I1 deliberately ineffective, Patch B disclosed | Intentional exposure | **EXECUTE** | APPLY | Shows ineffective defense; **not** a fully strong R1 |

`fixture_spec.json` uses source-native dispositions `REASSESS` and `BLOCKED_AT_BOUNDARY`; the implementation calls these guards `BLOCK_REASSESS` and `BLOCK_BOUNDARY`. The normalisation is explicit; these are not results invented by the independent runner.

An additional continuity control, CT08, changed the simulated freeze-effective time to **after** `t_act`, and correctly retained `EXECUTE/APPLY`. Thus the check is not simply “block whenever any `t_freeze` exists.”

## 4. Countertests: evidence of limited Q0/Q3/Q4/Q6 coverage

All seven below were executed **as separate test cases** on the unmodified, hash-verified source. All returned the clean-control verdict, action and gate text, even though the explicitly named input differed. These are **scope-extension probes**, not cases that Steven previously registered as supported. Their value is in identifying which S5 predicates remain assumptions rather than executable gates.

| ID | One changed input or inconsistency | Observed guard / attempt | Paired clean-control trace | Finding and interpretation |
|---|---|---|---|---|
| **CT01 — Q0** | `authority_state="REVOKED"` | `EXECUTE / APPLY` | **Identical** | `Q0 PASS` does not establish grant revocation checking |
| **CT02 — Q0** | `authority_state="different_principal_not_authorized"` | `EXECUTE / APPLY` | **Identical** | Principal/scope are not enforced by this evaluator |
| **CT03 — Q3** | `source_available=True` but `source_version="src@replaced-untrusted"` | `EXECUTE / APPLY` | **Identical** | Availability is not a pinned authoritative-version test; no source truth rule defined in this example |
| **CT04 — Q3** | `observed_at=1600000000`, versus `t_check=1700000000` | `EXECUTE / APPLY` | **Identical** | No numeric freshness budget is tested, despite trace text saying the observation is within the declared bound |
| **CT05 — Q4** | `current_generation=3`, but `supersession_lineage=[]` | `EXECUTE / APPLY` | **Identical** | Dependence on supplied lineage; no independent current-vs-queued generation comparison or source-set completeness proof |
| **CT06 — Q6** | `binding_tokens=[]` with otherwise valid frame | `EXECUTE / APPLY` | **Identical** | The exported binding-token field is not consulted. The native fixture does not specify separate invalid-token semantics, so this is *not* a proved native-case failure |
| **CT07 — Q6** | `t_act` missing from the supplied timestamp frame | `EXECUTE / APPLY` | **Identical** | The helper returns “no detected interval violation” on missing timing input; an invalid/incomplete frame is not rejected by the example's decision code |

**Code-level mechanism, verified against original bytes:**

- `implementation.py` **lines 236–302**, `_trace_gates_i2`, emits Q0 and Q1 `CONTROL_EXECUTED_PASS` unconditionally before considering the object. That is an assertion in the trace, not a direct verification of the promised authority/basis predicates.
- Within `_trace_gates_i2`, `authority_state`, `binding_tokens`, `current_generation` and `source_version` are **never read**. `source_available`, `supersession_lineage`, `freeze_state`, and the `timestamps` consulted by the Q6 helper do affect the chosen verdict.
- Q3 prints `source identity + observed_at inside the declared freshness bound` after checking only `source_available`. Steven's own [`fixture_spec.json`](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister/fixture_spec.json) explicitly says freshness is a Boolean for this fixture and deep Q3 semantics are excluded. **Therefore the observed CT03–CT04 behavior is consistent with an explicitly limited example, but cannot substantiate the stronger claim in the Q3 trace when extended to other evidence.**
- Q4 evaluates whether the **provided** `supersession_lineage` is nonempty; it does not independently acquire that lineage from a source or compare with a known expected generation. When the authorized source is guaranteed to supply a complete lineage, that may be sufficient for the selected fixture. CT05 tests the guarantee's absence.
- `_freeze_lands_inside_act_window` returns `False` if **any** of `t_check`, `t_act`, or `t_freeze` is absent. That is valid for the selected “no freeze” branch if the timestamps are complete and absence is meaningful; it is insufficient if a caller may supply malformed or missing timing evidence without separate validation.

**Do not interpret the seven observed attempts as seven actually applied RDS repairs.** `APPLY` is the *attempt channel returned by Steven's Python decision module* in these targeted runs. Our targeted runner does not execute Steven's original actuator or an external database write. Nor is it correct to describe these as seven author regression-suite failures. They demonstrate differential insensitivity of his selected abstract decision code to adversarial fields outside the published branch specification.

## 5. Q6 deserves a separate time-of-knowledge review, not a retrospective accusation

Two additional paired observations were deliberately registered:

- **BC01:** an initial-looking observation containing `t_check` and `t_act` but no information about a later freeze yields `EXECUTE`. This is indistinguishable to the deterministic evaluator from an otherwise identical world with a hidden subsequent freeze. It is **not** a disproof: no system can discover an information-theoretically inaccessible future event solely from that earlier observation.
- **BC02:** supplying a `t_freeze` inside the interval yields `BLOCK_BOUNDARY`. This is a **valid calculation on the supplied data**. The native single `Observation`, however, does not say *when* the candidate was permitted to learn that timestamp.

The independent differential confirms `PC01` and `BC01` produce the same verdict, and `PC06` and `BC02` produce the same verdict; `PC01` and `PC06` differ exactly when the additional freeze-effective fact is available.

The correct unresolved scientific question is **when and from which source the candidate learns `t_freeze`, and whether a real second check occurs at the actuation boundary**. An announced future-effective freeze and an unannounced intervening event are different experiments. A single call already supplied with `t_check`, `t_freeze`, and `t_act` does not by itself demonstrate online event acquisition, unannounced-change detection, or atomic binding of a broker to an RDS mutation. Conversely, the current result is valid for a bounded, stipulated complete frame or a legitimately known scheduled event.

**Minimal fair Q6 successor:** register `decision_at`, `event_effective_at`, `available_to_candidate_at`, `observed_at`, `actuation_attempt_at`, source/version at initial check, source/version at action-boundary check, and independently observed target state. Use one known-scheduled and one unannounced-after-initial-check event, with the host explicitly responsible for the late read. Preserve the original example unchanged as the historical control.

## 6. Other limitations, not contradicted by this targeted execution

### Q1 — Reconstruction is asserted, not operationally validated here

The I2 trace says the decision basis is reconstructable, but the exported Observation does not contain the incident/diagnosis/queued-basis history necessary to *test* complete causal reconstruction. This is a **static source observation** (not one of seven countertest findings). The native source's simplified gate table remains useful as a diagnostic illustration.

### Q2 — Recheck is modeled through supplied observations

The I2 result uses already-provided `Observation` values; there is no independent source acquisition process inside `implementation.py`. This does not invalidate a contract in which a separate collector supplies the current observation. A stronger architecture claim must separately validate collector/source authority, timestamps and evaluation-to-actuation binding.

### Q5 — Human escalation and scoped continuation are descriptive

For missing sources, the result is `HOLD_ESCALATE` with a note saying an owner and deadline were assigned, but the implementation has no externally acknowledged human response, timeout monitor, escalation authorization, or separately exercised unaffected workflow. This is a declared response-shape illustration, not experimentally verified bounded human intervention.

### Effect fidelity — independent state channel, deterministic actuator

The upstream [`harness.py` target model](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/blob/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister/harness.py) keeps its target outside `implementation.py` and reads it back. That **is a genuine structural improvement**: the guard does not report its own target state. But its `actuate()` changes the target deterministically on every `APPLY`, while `_assert_observation_coherence` requires `target_changed == (action == APPLY)`. Thus an “attempted-but-rejected”, partial, delayed, duplicate, or bypass-writer effect is not naturally represented as an ordinary valid outcome in this model. This is **a disclosed limitation** of the author fixture and a possible extension, not a reason to relabel its existing positives as false.

### Independent oracle and mutation score

The branch expected table, harness and decision module belong to a single authoring lineage. Source-code mutation, checker mutation, input faults and post-decision deviations are distinct and valuable sensitivity tests, but **a mutation score is evidence that specified mutations are detected, not proof that all S5 predicates were verified**. The current GitHub workflow records 17 gates and does not invoke `tools/impl-mutation-negctl.py` as a distinct CI step. The source-visible mutation scorer still has author-disclosed accounting/exemption limits. We did not independently execute the original full CI, mutation scorer, release-face checks or full `harness.py` suite in this Part 1. Their actual status should remain author-reported unless raw rerun evidence is attached.

### Separate `T08-S5Q2` model

Steven's separate four-case `T08-S5Q2` has a narrower native purpose (omitted condition vs complete reference, declared condition changed at use, legitimate continuity, and change after verdict). Its own README explicitly excludes deep Q3 and full S5 conformance. This Part 1 inspected its source/README and immutable blob identity but did not run its full selftest locally. None of the seven I2 countertest observations should be falsely attributed to this second example.

## 7. Suggested decision-ready technical status

| Candidate claim | Status under this Part 1 | Reason |
|---|---|---|
| Published bounded S5 examples are meaningful executable diagnostic artifacts | **SUPPORTED BY SOURCE + TARGETED DIRECT RUN** | Original I2 branch decisions reproduced; source pin verified; normal and positive controls survive |
| Steven's six frozen I2 scenario verdicts agree with stipulated expected dispositions | **SUPPORTED FOR SIX SELECTED BRANCHES** | Six pinned-fixture case expectations and direct decision outcomes agree; original stateful target outcomes not rerun here |
| I0/I1 are strong conventional R1/R2 comparators | **NOT ESTABLISHED / CONTRADICTS OWN LABELS** | The source explicitly calls I1 deliberately ineffective; no matched frozen strong comparator here |
| Each of S5 Q0–Q6 is substantively enforced by this one implementation | **NOT ESTABLISHED** | Seven adversarial expansions show Q0/Q3/Q4/Q6 insufficiency against broader S5 requirements; Q1/Q5 are trace assertions here |
| Q6 correctly blocks a supplied in-window freeze-effective event | **SUPPORTED WITHIN MODEL** | Exact timestamp comparison and observed `BLOCK_BOUNDARY` |
| Q6 discovers an unannounced freeze or proves a real atomic action boundary | **NOT ESTABLISHED** | No independently specified information-availability or two-stage live acquisition contract |
| S5/SF-006 detects an omitted required source absent from both reference and candidate | **NOT ESTABLISHED; EXPLICIT ASSUMPTION** | Stipulated complete reference; source-set discovery not provided |
| Target state is a distinct readback channel from the guard | **SUPPORTED IN SOURCE** | `TargetModel` belongs to harness and is probed separately |
| Native effect correctness/recovery under partial/rejected/bypass writes | **NOT EXERCISED** | Deterministic local actuator, no native RDS execution |
| A source-mutation score proves full S5 or DDS Stage C | **NOT SUPPORTED** | Checker/implementation mutation sensitivity is narrower than semantic/effect coverage |

## 8. What actually needs to be reviewed before answering Steven

The original contribution does not need to be rejected or rewritten. A technically honest response can **recognize the six-branch executable example as completed within its stated scope**, and ask whether the source owner intends the stronger `I2-complete`/Q0–Q6 trace language to refer merely to those stipulations or to a broader S5 gate-enforcement claim.

If **bounded illustrative scope**, the minimal correction is documentary: prominently state which gates are hard assumptions, which are actually evaluated, and which require a collector, authoritative source, timing protocol or effect model. Do not insist on implementing a full production system just to defend a pedagogical model.

If **stronger gate-conformance claim**, a prospective successor should address at least:

1. **Q0:** explicit positive and revocation/wrong-principal/wrong-scope controls with a typed authority/reference contract.
2. **Q3:** available-but-stale and wrong-source variants, known clock/freshness rules, and legitimate positive continuity.
3. **Q4:** source-derived current/queued generation comparison; separately recorded missing/suspicious lineage; unknown and inconclusive outcomes not silently converted to complete reference.
4. **Q6:** separate initial and action-boundary observations; legitimate availability time of an event; absent timing/binding-contract data cannot silently mean success.
5. **Q1/Q5:** only if a fuller S5 claim is sought, operational evidence for basis reconstruction and bounded response; not only explanatory trace strings.
6. **Actual effects:** only if claimed, an extended actuator model with rejected/partial/delayed/bypass transitions and externally observed target state.

For an eventual neutral cross-model evaluation, the first question is **which existing claim can already be closed**, not whether all conceivable new tests should run. This report records observations for Steven's technical line only; decisions on UC-4 campaign admission, future DDS stages, budgets or institutional acceptance belong in subsequent Parts 2–3.

## 9. Reproduction instructions and evidence register

Unpack the accompanying `.zip` anywhere and run:

```sh
python3 run_steven_focused_checks.py
python3 run_steven_focused_checks.py --quiet --output evidence/new_run.json
```

All tests use only Python's standard library. The script verifies the vendored original code's Git blob SHA before importing it and checks the pinned fixture against its own blob. It writes a structured JSON record including **every input, gate trace, attempt, verdict, expected disposition, case rationale and differential pairing**. The original sources are placed in `vendor_s5/` **without modification** and include the source author's MIT license; no restricted catalog prose is bundled.

The runner also accepts an explicit `--source /path/to/implementation.py`. It will refuse modified/unpinned code: this is intentional. To audit a newer revision, register it as a successor and deliberately update the expected source blob **and** the test contract; do not silently recast it as the historical run.

Evidence files:

- `evidence/focused_run.json` — full 18-case run, all inputs/trace lines, paired differential tests.
- `evidence/run_stdout.txt` — console result, including the 7 demonstrated scope gaps.
- `evidence/determinism_sha256.txt` — two byte-identical independent invocations in the same Python runtime.
- `evidence/integrity_negative_control.txt` — tampering a code byte caused the source-integrity gate to refuse the run.
- `MANIFEST_SHA256.txt` — checksums of all distributed package artifacts.

**Versioned references:** [Steven S5-Qregister](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/tree/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/S5-Qregister) · [Steven T08-S5Q2](https://github.com/zhaoxinghua09-cell/silent-failure-catalog/tree/b59a686b887c2a2545dd22808fb67e629bc95f18/examples/T08-S5Q2) · [UC-21 Annex S5](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/annexes/scenarios/S5.md) · [UC-21 T08](https://github.com/dakleyer/use-cases/blob/aec08fb5b0fac2ee399372370e9ee2a82a2d5779/contributions/when-controls-work-system-fails/annexes/technology/T08.md) · [Steven's reply on the 9 October corrections](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-6071913677).

---

**Final constrained finding:** Seven adversarial tests expose reproducible lack of sensitivity to selected Q0/Q3/Q4/Q6 fields in Steven's exact S5 decision module, alongside positive-control behavior that confirms the value of the existing model. Neither this result nor the author's own green controls is a sufficient basis for an all-gate, runtime-effect or vendor assurance claim. A factual technical discussion with Steven should preserve both sides of that statement, without prejudging what follow-up research, if any, Nelson may eventually admit.
