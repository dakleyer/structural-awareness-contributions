@zhaoxinghua09-cell @T-n-Nelson —

Steven, thank you for the latest revisions to S5-Qregister and T08-S5Q2. The executable contrasts, negative controls and improvements to the review machinery are meaningful contributions. I think the next step is to agree **what we have already established, what remains outside the model, and whether one further experiment is actually warranted**—rather than expanding the work indefinitely.

We have now prepared a separate, reproducible **focused technical review** against the pinned S5 implementation. It preserves the original source, tests the existing positive cases, and records additional adversarial variations. The review confirms the value of the six-branch diagnostic model, while showing that some broader S5 Q0/Q3/Q4/Q6 predicates are not substantively enforced by that decision module. Q1/Q5 and native target effects have further declared evidence limits. This is **not** a claim that the published six-branch tests are invalid, an AWS product result, or a complete independent audit. I would be happy to provide the self-contained report, runnable countertests, full traces and source hashes for your review before drawing stronger conclusions.

My preferred division of work would be:

1. **Technical review and source interpretation — Steven and the challenge contributors.** Agree which model claims are supported, which inputs and gates are stipulated, and which questions are genuinely unresolved. Steven remains the owner of his implementation and any proposed successor; our UC-21 material remains the challenge/reference source. Neither side should edit the other's frozen inputs or silently expand a result's scope.

2. **Experimental decision and bounded testing — Nelson, through UC-4 if he agrees.** Nelson, your [experimental-cycle proposal](https://github.com/FG-TIDA/use-cases/issues/4#issuecomment-5846988611) and your [S5 scope proposal](https://github.com/FG-TIDA/use-cases/issues/21#issuecomment-5936720586) seem to provide a good framework. I would welcome your assessment of whether our existing evidence is sufficient to close the current model-level exercise, or whether one additional question merits a controlled campaign. If warranted, I would ask you to lead the capability/scope assessment, agreed test contract, frozen inputs, execution and counter-tests, comparison and report, and to **recommend the stopping point** under an agreed resource limit.

   For a first **S5** experiment, your proposed Patch B supersession versus legitimate-continuity pair, G1/G4 sensitivity controls and separate **guard decision → attempted action → observed target state** remain a sensible candidate. The conventional strong comparator should have matched information and resources and receive full credit for success. A check or adapter mapping alone should not be called actual prevention. Your separate request for **one pinned catalogue-entry adapter** against UC-4 schema 1.1.0 is a distinct preparatory review, not an admitted S5 campaign.

   I also recognise that your most recent coordination offer concerned the **separate CDA candidate proposed by Matías**. I would not conflate CDA, Steven's model and the UC-4 adapter, or assume you have already committed to executing any of them. I am asking for your assessment of which, if any, should be admitted first.

3. **Scientific synthesis and possible specifications — only after experimental closure.** Once the bounded investigation is closed, a subsequent review—preferably including people other than the original model and test authors—can decide whether the findings support, revise or reject candidate DDS/EA specifications. This is not a request for UC-4 to certify EA, adopt a standard or preselect an architectural winner. A strong conventional solution that solves the problem is itself a successful research outcome.

For closure, I would suggest recording **(a)** the bounded question answered and contribution complete, **(b)** insufficient or inconclusive evidence with the exact limitation, or **(c)** one separately agreed successor question with new frozen inputs and budget. A valid corrected R1 baseline is required before calling any later change an R2 recurrence; an unannounced future event or a real target effect must not be inferred from a purely stipulated fixture.

**Steven**, do you regard the present contribution as complete at its stated executable-model scope, or is there one specific technical issue you would want to address after reviewing the focused evidence?

**Nelson**, would you be willing to serve as the UC-4 experimental lead and stopping-point assessor *if* a narrowly defined next campaign is justified? What admission conditions, capability limits and evidence would you require before recommending either a run or closure without one?

I would like us to leave this with a well-defined contribution, an attributable experimental record and a clear stopping point, rather than a growing chain of review-for-review's-sake.

Iván
