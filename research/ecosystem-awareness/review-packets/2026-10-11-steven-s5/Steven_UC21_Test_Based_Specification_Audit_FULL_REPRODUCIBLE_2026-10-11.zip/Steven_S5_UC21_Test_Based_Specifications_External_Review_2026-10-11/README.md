# Steven S5 / UC-21 — complete, offline-executable critical-review package

**Release:** 11 October 2026 | **Language:** English throughout | **Package status:** second-pass executed, reviewer-controlled technical audit, **not** a signed external-audit opinion, FG-TIDA adoption, or native AWS/RDS evaluation.

## Goal

This is a falsifiable **test-based specification-discovery** contribution. The question is not whether Steven's implementation follows a preferred Ecosystem Awareness architecture. The question is **which mechanism-neutral conditions are necessary and sufficient to distinguish legitimate continuity from unsafe execution in the frozen S5/Step Functions-style queued repair**, and whether further experiments are justified. The wider UC-21 research contains six scenario families; findings from one family are not automatically generalized to the rest. A successful strong conventional defence counts fully in the results. Draft technical specifications for possible FG-TIDA proposals are an expressly **later, separately reviewed** outcome.

## What is genuinely included

- **Original, byte-for-byte, pinned Steven source** (`upstream/implementation.py`) and its original fixture (`upstream/fixture_spec.json`), with source-owner MIT license and Git blob SHA checks. Not a derivative rewrite of his decision code.
- **An independent reviewer-controlled Python test runner**; 18 baseline cases, 15 second-pass targeted adversarial/control variants, static AST crosswalk and an exhaustive **6,480-combination synthetic sensitivity census** with a full row-level CSV.
- Deliberate negative controls verifying that the review runner detects false oracles, changed source/fixture files, always-execute and deny-all dummy cases.
- **Full raw records**, provenance registry, claim-by-claim assessment, explicit corrections of the previous audit and an external evaluator sign-off worksheet.
- An independently reviewable **UC-4/Nelson roles, admission and stopping proposal** and the final **raw GitHub Markdown draft**, included in this same ZIP.
- A copy of the earlier first-pass review and evidence, preserved unchanged in `appendices/` to support the review of our own revisions.

## One-command offline reproduction

Requires **Python 3.9+** and the Python standard library only. No network, AWS account, package installation, IDE, prior conversation or GitHub credentials are needed.

```bash
python3 verify_archive.py
python3 run_all.py
```

This verifies the integrity of the distributed source and evidence, runs both review suites and writes a fresh `replay/` directory containing:

- `focused_18.json` — complete named input/output/gate trace and expected-disposition records;
- `audit_result.json` — second-pass source reads, all 15 probes, negative controls and summary counts;
- `synthetic_full_factor_grid.csv` — **all 6,480 input/output records**;
- `RUN_SUMMARY.json` and `run_stdout.txt`.

The archived counterparts are in `records/`; replay results are not misrepresented as signatures by an external institution. Note that the 6,480 points are **synthetic combinations**, including deliberately inconsistent input contracts, **not** 6,480 physically admissible conformance cases.

Run individual parts if desired:

```bash
python3 audit/run_focused_18.py --output replay/standalone_18.json
python3 audit/extended_audit.py --out replay/second_pass
```

An altered original code/fixture SHA causes the review to refuse execution. For a new Steven revision, **freeze a new pin and create a separate audit successor**; do not silently change the old SHA constants and call it the same experiment.

## Reading order (recommended for a third-party reviewer)

1. `AUDIT_REPORT.md` — science, methods, evidenced findings, fair claim ceiling, formal correction of first pass, and ToR pathway.
2. `records/RUN_SUMMARY.json`, `records/audit_result.json` and `records/previous_focused_18.json` — actual recorded outputs.
3. `audit/extended_audit.py`, `audit/run_focused_18.py`, `upstream/implementation.py` and `upstream/fixture_spec.json` — independently inspect inputs, algorithms and oracle decisions.
4. `REVIEWER_SIGNOFF_WORKSHEET.md` — challenge our assumptions, attach independent evidence, and record claim-by-claim judgments.
5. `governance/UC4_NELSON_ROLES_AND_STOPPING_RULE.md` — proposed experiment/stop governance, **not a granted UC-4 authority**.
6. `COMMENT_FOR_GITHUB_RAW.md` — paste as-is in GitHub; short reference-style links render normally and keep the thread readable.

## Important execution and evidence boundaries

**Bundled offline:** Steven's exact original `S5-Qregister/implementation.py`, its fixture, our tests and all our output. **Not bundled/not run by us here:** Steven's original `harness.py --selftest` and full `examples/S5-Qregister/simulation.py` suite; his separate T08 `simulation.py --selftest`; his full mutation scorer, 16-step pinned workflow, AWS/RDS production environment, Nelson UC-4 experiment, or a human-verified oracle independent of the authored testcases. Source-level citations and Git blob identities for these additional files are recorded in `AUDIT_REPORT.md` and `SOURCE_REGISTRY.json`.

A reviewer **with their own network access** can independently obtain and run the author's full source at the pinned commit, as a **separately labelled** replication:

```bash
git clone https://github.com/zhaoxinghua09-cell/silent-failure-catalog.git
cd silent-failure-catalog
git checkout b59a686b887c2a2545dd22808fb67e629bc95f18
python3 examples/S5-Qregister/simulation.py --selftest
python3 examples/T08-S5Q2/simulation.py --selftest
python3 tools/impl-mutation.py
python3 tools/impl-mutation-negctl.py
```

Capture the interpreter version, command, exit status, full stdout/stderr and independent output hashes. A source-owner test's green result does **not** establish a successful real-world AWS implementation; nor does a non-executed test earn a passing status in our report. The pinned GitHub CI workflow declares **16** numbered gates, not 17.

## Reproducibility and scientific interpretation

The 15 second-pass probes and 6,480 combinations **characterize observable code dependencies**; they do not assert that every corrupted source/clock pair is an admissible input under Steven's documented fixture contract. A FAIL or an unchanged verdict needs individual scope/contract analysis before being called a technology fault. The value is in identifying where evidence is conditional and which hypotheses justify any later neutral UC-4 run.

The honest outcome is **a technical packet ready for a third party to review/re-execute**, not **an independent external audit already signed**. Our review harness and original scientific interpretation must themselves remain open to falsification.

**Attribution:** Steven Zhao owns the original MIT-licensed example code and fixtures. The new review harness, reports and draft process are prepared separately; no claim of Steven's endorsement or of FG-TIDA institutional status is made. Repository-level catalog prose under `LICENSE-CONTENT` is not reproduced.
