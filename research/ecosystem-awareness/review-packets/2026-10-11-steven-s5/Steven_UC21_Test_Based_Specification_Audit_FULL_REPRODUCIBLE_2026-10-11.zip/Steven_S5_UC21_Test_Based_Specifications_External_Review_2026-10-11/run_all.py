#!/usr/bin/env python3
"""One-command offline replay of reviewer-controlled tests against original pinned source.

Execution is neither a third-party sign-off nor execution of the author's complete
CI. No Python packages are required. Writes under `replay/` by default.
"""
from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import argparse

ROOT=Path(__file__).resolve().parent

def subprocess_call(args):
    p=subprocess.run(args,text=True,capture_output=True,cwd=ROOT)
    if p.returncode:
        print('FAILED COMMAND:',args,file=sys.stderr)
        print(p.stdout,file=sys.stderr)
        print(p.stderr,file=sys.stderr)
        raise SystemExit(p.returncode)
    return p.stdout

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=ROOT/'replay')
    args=ap.parse_args()
    out=args.out.resolve()
    out.mkdir(parents=True,exist_ok=True)
    integrity=subprocess_call([sys.executable,str(ROOT/'verify_archive.py')])
    focus=subprocess_call([sys.executable,str(ROOT/'audit'/'run_focused_18.py'),
          '--output',str(out/'focused_18.json')])
    grid=subprocess_call([sys.executable,str(ROOT/'audit'/'extended_audit.py'),
          '--out',str(out)])
    f=json.loads((out/'focused_18.json').read_text())
    j=json.loads((out/'audit_result.json').read_text())
    assert f['sample_size']==18 and f['all_observed_as_registered']
    assert j['factor_grid']['synthetic_combinations']==6480
    assert j['factor_grid']['metadata_invariance_holds_for_all_routing_signatures']
    assert j['negative_controls']['deliberate_false_oracle']=='REJECTED_AS_REQUIRED'
    summary={'status':'REPLAY_SUCCEEDED_AT_DECLARED_BOUNDARY',
       'upstream_source_git_blob':j['git_blob_source'],
       'previous_focused_cases':f['sample_size'],
       'new_targeted_variations':len(j['targeted_probes']['variations']),
       'synthetic_cross_products':j['factor_grid']['synthetic_combinations'],
       'grid_result_sha256':sha256((out/'audit_result.json').read_bytes()).hexdigest(),
       'scope':'Independent reviewer-controlled evaluation of a pinned decision module; not a native AWS test or author full CI.'}
    (out/'RUN_SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    (out/'run_stdout.txt').write_text(integrity+'\n'+focus+'\n'+grid)
    print(integrity.strip())
    print('FOCUSED 18:',f['sample_size'],'checked, adversarial invariance pairs reproduced; see JSON for interpretation')
    print('TARGETED SECOND PASS:',len(j['targeted_probes']['variations']))
    print('FACTORIAL SENSITIVITY CENSUS:',j['factor_grid']['synthetic_combinations'],
          'synthetic cross-products, NOT 6,480 valid-world conformance proofs')
    print('NEGATIVE CONTROLS:',len(j['negative_controls']))
    print('NO S5 ALL-GATE, R1/R2, NATIVE AWS OR UC4 CAMPAIGN ASSURANCE IS CLAIMED.')
    print('OUTPUT:',out)

if __name__=='__main__':
    main()
