# External evaluator worksheet — independent determination requested, not pre-filled

This review packet is **not** a signed independent audit. The undersigned evaluator should supply an independent, evidence-linked disposition instead of relying on the packet author's interpretation.

## Reviewer and custody information

- Evaluator name / institutional affiliation:
- Contact / independent conflict-of-interest declaration:
- Assessment period and timezone:
- Exact source pins reviewed (commit and Git blob SHA):
- Host OS / Python version / deterministic environment details:
- Package SHA-256, local chain of custody, independent output hashes:
- Commands, exact stdout/stderr and exit codes (attach files):
- Did you review the whole source-owner harness / T08 suites? If not, mark NOT_RUN:
- Did you derive any test expected outcome independently of the original code AND of the supplied reviewer harness? Attach method:
- Did you test the test runner against at least one adverse or bogus-expected input? Attach result:
- Were any material semantic assumptions revised AFTER seeing outputs? If yes, preserve both versions:

## Claims and dispositions (one explicit judgment each)

| Claim | Recommended initial evidence ceiling | External reviewer disposition: SUPPORTED / CONTRADICTED / NOT_ESTABLISHED / OUT_OF_SCOPE / NOT_RUN | Independent evidence ref |
|---|---|---|---|
| Original S5 decision source and fixture match named Git blob hashes | EXECUTED_PINNED |  |  |
| Clean S5 continuity executes under the stipulated six-branch model | EXECUTED_PINNED |  |  |
| Known Patch-B supersession requalifies | EXECUTED_PINNED |  |  |
| Known active freeze blocks | EXECUTED_PINNED |  |  |
| Known unavailable source holds/escalates | EXECUTED_PINNED |  |  |
| In-window freeze time supplied to Q6 blocks | EXECUTED_PINNED |  |  |
| Q0 checks revocation and principal scope substantively | NOT_ESTABLISHED_IN_TESTED_FUNCTION |  |  |
| Q3 checks source-version identity and a freshness TTL | OUTSIDE_DECLARED_ORIGINAL_FIXTURE |  |  |
| Q4 validates collector-provided supersession against current state independently | NOT_ESTABLISHED_IN_TESTED_FUNCTION |  |  |
| Q5 performs operational bounded human escalation | NOT_EXERCISED |  |  |
| Q6 acquires an unannounced event at the real action boundary | NOT_EXERCISED |  |  |
| Target readback structurally distinct from decision module | STATIC_SOURCE_SUPPORT |  |  |
| Non-deterministic or external target effect and business result F_I | NOT_EXERCISED |  |  |
| Original source-owner full CI and mutation gates independently rerun | NOT_RUN_IN_THIS_PACKET |  |  |
| Steven I1 is strong UC-21 R1 comparator | CONTRADICTED_BY_AUTHOR_SCOPE |  |  |
| Steven I2 represents frozen corrected R1 challenged in true R2 | NOT_ESTABLISHED |  |  |
| Native AWS Step Functions/RDS result | NOT_TESTED |  |  |
| FG-TIDA deliverable, accepted standard or UC-4 experiment admission | NOT_GRANTED |  |  |

## Disconfirmation probes or alternative interpretations

1. Which of the reviewed findings is most likely **wrong** given the actual contract? How would you falsify it?
2. Can a complete, source-authorized observation collector establish revocation/freshness/lineage/clock validity outside the tested function? If so, supply an implementable mapping and check its sufficiency against the original frozen S5 Challenge.
3. If a competent conventional strong peer closes S5 without any new EA requirement, has this been fully credited and preserved?
4. If the model only claims the six bounded branches, does its claim language require a clarification but no new implementation?
5. Are the 6,480 synthetic combinations properly separated from admissible-world conformance tests?

## Auditor's signed conclusion

- Technical contribution label:
- Supported exact claims:
- Failed/contradicted exact claims:
- What remains NOT_RUN/NOT_ESTABLISHED:
- If proposing a further campaign: precise question, independent observable, strong comparator, resources and stopping condition:
- Reviewer recommendation: CLOSE_BOUNDED / NO_ADMISSION / ONE_BOUNDED_SUCCESSOR / MORE_SOURCE_INFORMATION_REQUIRED:
- Date, signature and archived record URL:

**This form does not grant UC-4 admission or FG-TIDA approval.**
